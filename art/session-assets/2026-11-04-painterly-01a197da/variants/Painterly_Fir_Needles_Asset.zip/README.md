# 針葉樹・枝葉と頂部の修正版

下側に露出していた輪状パーツを削除。長い一枚の頂部を短い針葉の房へ変更しました。
幅広い一枚葉ではなく、細い針葉が並ぶ小枝のまとまりを、曲がった立体メッシュへ配置しています。

## ファイル
- Painterly_Fir.glb：画像・UV・頂点カラー・法線を内蔵したゲーム用モデル。
- Painterly_Fir.blend：編集可能なモデル。同梱Texturesを参照します。
- Textures/BarkColor.png：幹の色画像。
- Textures/NeedleSpray.png：針葉の筆跡と透明度。白灰色の画像を頂点カラーで緑にしています。

11,196三角形、GLB 1メッシュ・2材質・2画像。高さ約4.7m。
葉は標準glTFのAlpha Mask（しきい値0.35）と頂点カラー（COLOR_0）を使用します。
GLBをそのまま読み込む場合、Three.js等で自動的に再現されます。
色画像はsRGB、粗さ0.95、金属度0。床・ライト・カメラは含みません。
ZIPはフォルダごと展開してください。

参考：Arnold Arboretumの針葉樹コレクション
https://arboretum.harvard.edu/collections/conifer-collection/

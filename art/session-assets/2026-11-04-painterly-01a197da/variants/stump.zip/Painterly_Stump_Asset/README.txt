Painterly Stump - standalone game asset, revision 3

Files:
- Stump_Painterly.glb: ready to import, texture embedded.
- Stump_Painterly.blend: editable mesh and packed baked texture; asset only.
- Textures/stump_basecolor.png: 2048 x 2048 sRGB colour atlas.

One closed mesh, 3,840 triangles, one material, one UV set.
Metres. Blender Z-up; GLB Y-up. Pivot at ground centre.
Roughness 0.92; metallic 0. No extra maps required.
Painted colour, root moss and height shading are baked into base colour.
Use soft neutral lighting; strong light changes the PBR appearance.
No scene, ground, camera, light or viewer is included.

New geometry and generated painted surface textures; not the earlier scene stump.
Created in Blender 5.2.2. Does not require Stylized Asset Suite.
Generation uses built-in image_gen for surface textures, then Blender UV/colour baking.
GLB re-import, manifold mesh, embedded texture byte match and ZIP CRC verified.

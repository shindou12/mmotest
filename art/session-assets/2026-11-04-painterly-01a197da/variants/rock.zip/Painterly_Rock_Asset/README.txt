Painterly Rock - standalone asset, revision 2

Rock_Painterly.glb: ready to import, colour texture embedded.
Rock_Painterly.blend: editable asset mesh with packed colour texture.
Textures/rock_basecolor.png: 2048 x 2048 sRGB colour atlas.

134 triangles, 1 closed mesh, 1 UV set, 1 material.
Metres. Blender Z-up; GLB Y-up. Origin at ground centre.
Dimensions ~1.89 x 1.52 x 1.22 m in Blender XYZ.
Roughness 0.92, metallic 0. No additional maps required.
Painted surface, artistic facet shading and foot moss are baked into base colour.
Generated surface texture and authored Blender geometry. No add-on required.
No scene, presentation floor, camera, lights or viewer is included.
GLB re-import, topology, embedded texture byte match and ZIP CRC verified.

22 executed Blender workflows — replay recipes

Blender 5.2.2 LTS, Cycles CPU. Use --threads 4. Sources start from empty scene;
previous meshes are not inputs. Shared primitive/normal-transfer helpers and frozen
pigment PNGs are deliberately reused. This archive is the recipe pack, not the
runtime model pack. Download individual model ZIPs from the viewer.

Cart: blender -b --python cart/M06/replay.py -- corrected
Other cart methods: blender -b --python cart/build_cart.py -- M01 corrected
Tree: blender -b --python tree/M13/source.py
Stump: blender -b --python stump/M17/source_production/build_method.py -- M17 production
Repeat: blender -b --python stump/M17/source_repeat_final/build_method.py -- M17 repeat_final
Extra cart: blender -b --python cart/M21/replay.py -- corrected
Extra tree: blender -b --python tree/M22/replay.py -- corrected

Run in a copied working directory: output files are generated beside the recipe.
Tree per-method sources and stump snapshots contain their local review rig.
The stump recipes in this combined archive share stump/palette; keep the whole
stump directory together when replaying. Source snapshot notes describe the
original local layout; this archive deduplicates the exact same pigment PNGs.
Generated source image for M22 is frozen; rerunning image generation is not
deterministic. No image/API key or paid service is needed for replay.
Pigment authoring helpers use Pillow outside Blender; supplied PNGs are sufficient
for replay, and authoring helpers use their own local path in this archive.

The archive includes observed issues, rejected trials and limits. Shared high/low
baking and directional UV foundations are disclosed, rather than claimed as
unrelated inventions. The larger local experiment retains every editable model,
initial/final render and source high mesh. Those are intentionally outside this
small recipe download.

# Run with Blender: blender -b --python replay.py -- initial|corrected
import sys, pathlib, runpy
root=pathlib.Path(__file__).resolve().parent.parent
stage=sys.argv[-1] if sys.argv[-1] in ('initial','corrected') else 'corrected'
sys.argv=['build_cart.py','--','M04',stage]
runpy.run_path(str(root/'build_cart.py'),run_name='__main__')

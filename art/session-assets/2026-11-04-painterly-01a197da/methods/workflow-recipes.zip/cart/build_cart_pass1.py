"""Cargo cart method lab. Each build begins from an empty scene, no previous mesh import.
Invocation: blender -b --python build_cart.py -- M01 initial|corrected
"""
import bpy, math, random, sys, pathlib, json, shutil
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:];MID=args[0];STAGE=args[1] if len(args)>1 else 'initial'
OUT=ROOT/MID;OUT.mkdir(exist_ok=True);FIX=STAGE=='corrected';random.seed(100+int(MID[1:]))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for m in list(bpy.data.materials):bpy.data.materials.remove(m)
ASSET=[];EVIDENCE=[]
def rgb(t):
 return tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in [x/255 for x in t])+(1,)
def mat(name,col,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=rgb(col);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rgb(col);p.inputs['Roughness'].default_value=.8;p.inputs['Metallic'].default_value=metal;return m
metal=mat('quiet blue-brown iron',(69,70,61),.35)
end=mat('warm endgrain',(184,134,72));dark=mat('recessed wood',(111,72,39));light=mat('fresh worn facets',(207,158,88))
wood=bpy.data.materials.new('painted directional oak');wood.use_nodes=True
nt=wood.node_tree;p=nt.nodes.get('Principled BSDF');p.inputs['Roughness'].default_value=.86
tex=nt.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(OUT/'wood_trim.png'));nt.links.new(tex.outputs['Color'],p.inputs['Base Color'])

def track(o):
 ASSET.append(o);return o

def apply(o,m):
 bpy.context.view_layer.objects.active=o
 try:bpy.ops.object.modifier_apply(modifier=m.name)
 except Exception as e:EVIDENCE.append(str(e))

def bevel(o,width=.028,segments=2):
 m=o.modifiers.new('hand softened broad corners','BEVEL');m.width=width;m.segments=segments;apply(o,m)
 # flat polygon normals preserve facets; modest bevel strips catch light
 return o

def uvtrim(o,band=None):
 if not o.data.uv_layers:o.data.uv_layers.new(name='directional_paint')
 band=random.randrange(4) if band is None else band
 coords=[v.co for v in o.data.vertices];mn=[min(v[i] for v in coords) for i in range(3)];mx=[max(v[i] for v in coords) for i in range(3)]
 order=sorted(range(3),key=lambda i:mx[i]-mn[i],reverse=True);a,b=order[:2]
 for poly in o.data.polygons:
  # align every long face with grain; minor end faces are quieter flat colour
  if abs(poly.normal[a])>.7:poly.material_index=1
  for li in poly.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co
   u=(co[a]-mn[a])/max(mx[a]-mn[a],1e-5)
   v=(co[b]-mn[b])/max(mx[b]-mn[b],1e-5)
   o.data.uv_layers.active.data[li].uv=(.02+.96*u,(band+.06+.88*v)/4)
 o.data.materials.clear();o.data.materials.append(wood);o.data.materials.append(end)

def box(name,loc,dim,material=wood,bev=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=dim
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if material==wood:uvtrim(o)
 else:o.data.materials.append(material)
 if bev:bevel(o,bev)
 return track(o)

def beam(name,a,b,width,depth=None,material=wood,bev=.025):
 a,b=Vector(a),Vector(b);v=b-a
 o=box(name,(a+b)/2,(v.length,width,depth or width),material,bev)
 o.rotation_euler=v.to_track_quat('X','Z').to_euler();return o

def extrude_polygon(name,pts,depth,axis='Y',offset=0,material=wood):
 # Explicit silhouette polygon extruded normal to its drawing plane.
 verts=[]
 for s in [-1,1]:
  for a,b in pts:verts.append((a,offset+s*depth/2,b) if axis=='Y' else (offset+s*depth/2,a,b))
 n=len(pts);faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o)
 if material==wood:uvtrim(o)
 else:me.materials.append(material)
 bevel(o,.025,2);return track(o)

def ring(name,center,radius,width,depth,material=wood,n=48):
 # Closed annular profile swept around Y, coarse irregular felloes.
 cx,cy,cz=center;verts=[]
 for y in [-depth/2,depth/2]:
  for r in [radius-width,radius]:
   for i in range(n):
    a=i*2*math.pi/n; rr=r*(1+.004*math.sin(i*3.1));verts.append((cx+rr*math.cos(a),cy+y,cz+rr*math.sin(a)))
 faces=[]
 for i in range(n):
  j=(i+1)%n
  faces.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o)
 if material==wood:uvtrim(o,2)
 else:me.materials.append(material)
 bevel(o,.015,2);return track(o)

def cylinder(name,center,radius,depth,material):
 bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=radius,depth=depth,location=center,rotation=(math.pi/2,0,0));o=bpy.context.object;o.name=name;o.data.materials.append(material);bevel(o,.016,2);return track(o)

def wheels(cx=.20,r=.72,spacing=.94,count=10,thin=False):
 for side in [-1,1]:
  y=side*spacing;cz=r+.025
  ring('wide oak felloe', (cx,y,cz),r,.105,.16 if not thin else .09)
  ring('restrained outer iron tire',(cx,y,cz),r+.023,.028,.185 if not thin else .11,metal)
  for i in range(count):
   a=i*2*math.pi/count+.05
   a0=(cx+.13*math.cos(a),y,cz+.13*math.sin(a));b0=(cx+(r-.075)*math.cos(a),y,cz+(r-.075)*math.sin(a))
   beam('radial tapered oak spoke',a0,b0,.075 if FIX else .105,.105,bev=.014)
  cylinder('large warm carved hub',(cx,y,cz),.18,.30,wood)
  # UV map cylinder after adding wood
  uvtrim(ASSET[-1],1)
  cylinder('small quiet axle cap',(cx,y+side*.175,cz),.092,.055,metal)
 beam('load-bearing axle',(cx,-spacing-.18,r+.025),(cx,spacing+.18,r+.025),.16,.16,dark)

def standard_body(length=2.0,width=1.35,floorz=.93,rows=3,wall=.65,flare=.12,irregular=False):
 # Conventional blockout driven by the measured reference, not imported geometry.
 for i in range(6):
  y=-width/2+(i+.5)*width/6
  box('wide floor plank',(-.08,y,floorz),(length,width/6-.016,.105),bev=.018)
 for side in [-1,1]:
  for j in range(rows):
   z=floorz+.15+(j+.5)*wall/rows;y=side*(width/2+.02+flare*(j+1)/rows)
   o=box('broad sidewall plank',(-.08,y,z),(length+.13,.095,wall/rows-.016),bev=.027)
   if irregular:o.rotation_euler.y=math.radians(random.uniform(-1.3,1.3));o.rotation_euler.z=math.radians(side*1.2)
  for x in [-length/2+.02,length/2-.16]:
   beam('upright pinned wall stake',(x,side*(width/2+.10),floorz-.10),(x,side*(width/2+flare+.10),floorz+wall+.22),.13,.14)
 for x in [-length/2-.03,length/2-.13]:
  for j in range(rows):
   z=floorz+.15+(j+.5)*wall/rows
   o=box('broad endwall plank',(x,0,z),(.10,width+.12+flare*1.5,wall/rows-.016),bev=.023)
 for y in [-width*.38,width*.38]:
  beam('subframe longitudinal sill',(-length/2-.15,y,floorz-.10),(length/2+.03,y,floorz-.10),.16,.18,dark)


def shafts(front=-1.1,length=1.8,width=.95,z=.85,curved=False):
 for side in [-1,1]:
  if curved:
   curved_board('bent ash pulling shaft',[(front+.12,side*width/2,z),(front-.5,side*(width/2+.03),z+.04),(front-length,side*(width/2+.13),z-.08)],.10,.11)
  else:
   beam('long forward pulling shaft',(front+.10,side*width/2,z),(front-length,side*(width/2+.12),z-.13),.105,.125)
  box('dark shaft grip collar',(front-length+.14,side*(width/2+.11),z-.11),(.06,.125,.14),metal,.012)


def hardware(length=2,width=1.35,floorz=.93,wall=.65):
 for x in [-length/2+.02,length/2-.16]:
  for side in [-1,1]:
   y=side*(width/2+.12)
   # Tiny fastening plates only at load-bearing sill, not on every plank.
   box('sill joint iron shoe',(x,y,floorz+.015),(.19,.035,.15),metal,.012)
   cylinder('joint pin',(x,y+side*.027,floorz+.015),.035,.035,metal)

def curved_board(name,points,w,h):
 # Actual Bezier guide + Curve modifier, retained source in separate construction blend.
 length=sum((Vector(b)-Vector(a)).length for a,b in zip(points,points[1:]));origin=Vector(points[0]);direction=(Vector(points[-1])-origin).normalized()
 # A local X curve: coordinates relative to root, with main direction usually X.
 cu=bpy.data.curves.new(name+' shaping guide','CURVE');cu.dimensions='3D';sp=cu.splines.new('BEZIER');sp.bezier_points.add(len(points)-1)
 for bp,pnt in zip(sp.bezier_points,points):bp.co=Vector(pnt)-origin;bp.handle_left_type='AUTO';bp.handle_right_type='AUTO'
 c=bpy.data.objects.new(name+' curve',cu);bpy.context.collection.objects.link(c);c.location=origin
 # Main orientation can decrease X: reverse points to ensure +X deformation.
 if points[-1][0]<points[0][0]:
  bpy.data.objects.remove(c,do_unlink=True);return curved_board(name,list(reversed(points)),w,h)
 ln=points[-1][0]-points[0][0];N=14;verts=[]
 for i in range(N+1):
  for y,z in [(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)]:verts.append((ln*i/N,y,z))
 faces=[(3,2,1,0),(4*N,4*N+1,4*N+2,4*N+3)]
 for i in range(N):
  for j in range(4):faces.append((4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j))
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.location=origin;uvtrim(o);track(o)
 m=o.modifiers.new('curve-designed warp','CURVE');m.object=c;m.deform_axis='POS_X';apply(o,m);bevel(o,.018,2)
 # Guide preserved in construction archive via point coordinates JSON; no guide object in model export.
 EVIDENCE.append({'curve':name,'points':points});bpy.data.objects.remove(c,do_unlink=True);return o


def build01():
 # Read hand-measured guide. Single wheel unit converted to world metres.
 ratios=json.loads((ROOT/'reference_measurements.json').read_text())['ratios_wheel_diameter_1'];r=.72
 L=ratios['bed_length']*r*2*.76;W=1.35;wall=.70 if not FIX else .57
 standard_body(L,W,.99,3,wall,.09,True);shafts(-L/2-.08,1.85,W*.76,.88);wheels(.24,r,.94,10);hardware(L,W,.99,wall)
 EVIDENCE.append({'reference':'reference_3view.png','measured_ratios':ratios,'artistic_interpretation':'Retained broad side planks and wheel-to-bed ratio; corrected wall lower than generated concept to expose load bed.'})


def build02():
 # Draw the side outline first. The first pass intentionally shallow depth tests its 2.5D weakness.
 W=1.0 if not FIX else 1.48;fz=.96;wall=.63
 for s in [-1,1]:
  for j in range(3):
   z=fz+.12+j*.22
   pts=[(-1.13,z+.02),(-.96,z-.01),(.91,z+.015),(1.04,z+.07),(1.04,z+.22),(.25,z+.235),(-1.08,z+.215)]
   extrude_polygon('drawn side silhouette row',pts,.105,'Y',s*(W/2+.04+j*.035))
 for j in range(5):
  box('depth-bridging floor',(-.04,-W/2+(j+.5)*W/5,fz),(2.17,W/5-.012,.10),bev=.025)
 for x in [-1.08,.98]:
  for j in range(3):
   z=fz+.13+j*.22
   pts=[(-W/2-.10,z),(W/2+.10,z+.012),(W/2+.13,z+.20),(-W/2-.13,z+.21)]
   extrude_polygon('front elevation plank extruded',pts,.1,'X',x)
 for s in [-1,1]:
  for x in [-1.02,.91]:beam('silhouette stake',(x,s*(W/2+.12),.83),(x,s*(W/2+.24),1.85),.12,.14)
 shafts(-1.18,1.70,W*.75,.82);wheels(.18,.73,W/2+.26,8,not FIX);hardware(2.2,W,.96,.65)
 EVIDENCE.append('Side and front profile polygons are primary source; corrected pass expands transverse depth and thickens wheel felloe, preserving drawn elevation.')


def build03():
 L=2.28;W=1.42;fz=.95
 # Build skeletal load path first, joints are actual intersecting mortise/tenon geometry.
 for y in [-.48,.48]:beam('main chassis oak sill',(-1.25,y,.80),(1.18,y,.80),.19,.21)
 for x in [-.98,.20,.99]:
  beam('transverse pegged bearer',(x,-.84,.83),(x,.84,.83),.19,.16)
 for side in [-1,1]:
  for x in [-1.01,.99]:
   post=box('mortised hardwood corner post',(x,side*.79,1.28),(.17,.17,.98 if not FIX else .82),bev=.015)
   # Boolean mortise at lower joint visibly opens on inner X face.
   cut=box('TEMP mortise cutter',(x,side*.79,1.05),(.27,.09,.10),dark,0);ASSET.remove(cut)
   mod=post.modifiers.new('true transverse mortise','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cut;apply(post,mod);bpy.data.objects.remove(cut,do_unlink=True)
   beam('tenon pinned into corner', (x-.13,side*.79,1.05),(x+.13,side*.79,1.05),.075,.08,dark,.008)
 # Cargo bed is supported by the skeleton, side planks socket between posts.
 for i in range(6):box('load floor board',(-.01,-.68+(i+.5)*W/6,fz),(L,W/6-.015,.10),bev=.018)
 for s in [-1,1]:
  for j in range(3):
   box('side board between joinery posts',(-.01,s*.77,1.13+j*.205),(2.15,.10,.18),bev=.022)
  # First pass has long obtrusive diagonal; fix moves it under bed, visibly clarifies broad side mass.
  if not FIX:beam('outside load brace',(-1,s*.87,1.05),(.97,s*.87,1.67),.11,.075,dark)
  else:beam('underslung diagonal brace',(-.88,s*.49,.78),(.75,s*.49,.91),.12,.09,dark)
 for x in [-1.06,1.05]:
  for j in range(3):box('pegged endboard',(x,0,1.13+j*.205),(.10,1.40,.18),bev=.02)
 shafts(-1.25,1.86,1.06,.84);wheels(.27,.74,.98,10);hardware(L,W,.95,.65)
 EVIDENCE.append('Assembly order is chassis -> cross-bearers -> bored mortised posts -> tenon keys -> floor -> walls. Structural frame is not a reused previous cart.')


def build04():
 # Deliberately simple low cage. Actual high-to-low bake is performed after assembly.
 standard_body(2.15,1.36,.97,3,.62,.11,False);shafts(-1.2,1.75,1.02,.84);wheels(.19,.74,.96,10);hardware(2.15,1.36,.97,.62)
 EVIDENCE.append('All low meshes duplicated to high; low bevels removed for crisp cage, high receives bevel segments 5 + weighted normals. Selected-to-active tangent normal bake uses a 0.08m ray distance.')


def build05():
 # UV-first: every member is dimensioned to the same 4 directional painted trim bands.
 L=2.22;W=1.42;fz=.96
 for j in range(6):box('trim board floor A',(-.03,-W/2+(j+.5)*W/6,fz),(L,W/6-.014,.12),bev=.018)
 for s in [-1,1]:
  for j in range(3):
   o=box('trim board side band '+str(j),(-.03,s*(.75+j*.025),1.14+j*.215),(L+.1,.105,.20),bev=.025)
   uvtrim(o,j if FIX else 1)
  for x in [-1.07,.99]:
   p=beam('vertical trim stake',(x,s*.85,.86),(x,s*.89,1.82),.13,.13);uvtrim(p,3)
 for x in [-1.13,1.08]:
  for j in range(3):box('cross grain endboard',(x,0,1.14+j*.215),(.11,W+.1,.2),bev=.024)
 shafts(-1.21,1.84,1.03,.85);wheels(.22,.75,.99,10);hardware(L,W,.96,.65)
 # Actual initial texture UV defect: intentional side UV orientation points grain across boards.
 if not FIX:
  for o in ASSET:
   if 'trim board side' in o.name:
    for uv in o.data.uv_layers.active.data:uv.uv=(.18+uv.uv.y*.4,uv.uv.x)
 EVIDENCE.append('UV construction maps each member longest dimension to U and selects its material band on V. Corrected all side board UVs to long-axis grain and distributed 3 bands to avoid repeated stripe.')


def build06():
 L=2.30;W=1.43;fz=.95;warp=.095 if not FIX else .035
 for j in range(6):
  y=-W/2+(j+.5)*W/6
  curved_board('curved old floor',[(-1.15,y,fz),(-.35,y+.012,fz+.016),(1.10,y,fz-.01)],W/6-.012,.11)
 for s in [-1,1]:
  for j in range(3):
   z=1.13+j*.225;y=s*(.77+j*.025)
   curved_board('bowed reclaimed side plank',[(-1.19,y,z),(-.33,y+s*warp,z+warp*(j-1)),(.42,y+s*warp*.8,z-warp*.6),(1.12,y,z+.012)],.105,.195)
  for x in [-1.10,1.02]:beam('crooked outer upright',(x,s*.86,.84),(x+.02,s*.91,1.86),.14,.145)
 for x in [-1.15,1.10]:
  for j in range(3):box('old end board',(x,0,1.13+j*.225),(.11,W+.08,.195),bev=.025)
 for y in [-.5,.5]:beam('continuous chassis sill',(-1.28,y,.83),(1.18,y,.83),.17,.17,dark)
 shafts(-1.26,1.87,1.06,.85,True);wheels(.22,.75,.99,10);hardware(L,W,.95,.66)
 EVIDENCE.append({'warp_amplitude':warp,'workflow':'Bezier guides deform subdivided board stock with real Curve modifiers, then soft bevel; direction-aware painterly UVs travel with deformed mesh.'})


def gn_group():
 g=bpy.data.node_groups.new('Cargo cart | dimensioned stock assembly','GeometryNodeTree');g.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry');g.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
 for name,value in [('Bed Length',2.22),('Bed Width',1.42),('Floor Height',.96),('Wall Row Height',.215),('Stock Thickness',.105)]:
  s=g.interface.new_socket(name=name,in_out='INPUT',socket_type='NodeSocketFloat');s.default_value=value;s.min_value=.05;s.max_value=6
 n=g.nodes;l=g.links;inp=n.new('NodeGroupInput');inp.location=(-900,300);out=n.new('NodeGroupOutput');out.location=(900,200);join=n.new('GeometryNodeJoinGeometry');join.location=(450,200)
 def assembly(label,count,start,offset,size,material,row):
  line=n.new('GeometryNodeMeshLine');line.name=label+' distribution';line.label=label;line.location=(-650,row);line.inputs['Count'].default_value=count;line.inputs['Start Location'].default_value=start;line.inputs['Offset'].default_value=offset
  cube=n.new('GeometryNodeMeshCube');cube.location=(-650,row-140);cube.inputs['Size'].default_value=size
  inst=n.new('GeometryNodeInstanceOnPoints');inst.location=(-300,row);l.new(line.outputs['Mesh'],inst.inputs['Points']);l.new(cube.outputs['Mesh'],inst.inputs['Instance'])
  real=n.new('GeometryNodeRealizeInstances');real.location=(-50,row);l.new(inst.outputs['Instances'],real.inputs[0])
  attr=n.new('GeometryNodeStoreNamedAttribute');attr.data_type='INT';attr.domain='FACE';attr.location=(130,row);attr.inputs['Name'].default_value='component_id';attr.inputs['Value'].default_value=len([x for x in n if x.bl_idname=='GeometryNodeStoreNamedAttribute']);l.new(real.outputs[0],attr.inputs['Geometry'])
  setm=n.new('GeometryNodeSetMaterial');setm.location=(300,row);setm.inputs['Material'].default_value=material;l.new(attr.outputs[0],setm.inputs[0]);l.new(setm.outputs[0],join.inputs[0]);return line,cube
 floor,fc=assembly('floorboards',6,(-.03,-.60,.96),(0,.24,0),(2.22,.225,.11),wood,0)
 # Interface drives cube length through CombineXYZ; not decorative unused inputs.
 fsz=n.new('ShaderNodeCombineXYZ');fsz.location=(-880,-150);l.new(inp.outputs['Bed Length'],fsz.inputs['X']);fsz.inputs['Y'].default_value=.225;fsz.inputs['Z'].default_value=.11;l.new(fsz.outputs[0],fc.inputs['Size'])
 for side,row in [(-1,350),(1,750)]:
  sl,sc=assembly('sidewall '+str(side),3,(-.03,side*.77,1.14),(0,side*.02,.215),(2.34,.105,.195),wood,row)
  sz=n.new('ShaderNodeCombineXYZ');sz.location=(-900,row-80);l.new(inp.outputs['Bed Length'],sz.inputs['X']);l.new(inp.outputs['Stock Thickness'],sz.inputs['Y']);sz.inputs['Z'].default_value=.195;l.new(sz.outputs[0],sc.inputs['Size'])
 for x,row in [(-1.15,-420),(1.09,-850)]:
  el,ec=assembly('endwall '+str(x),3,(x,0,1.14),(0,0,.215),(.105,1.52,.195),wood,row)
  sz=n.new('ShaderNodeCombineXYZ');sz.location=(-900,row-80);sz.inputs['X'].default_value=.105;l.new(inp.outputs['Bed Width'],sz.inputs['Y']);sz.inputs['Z'].default_value=.195;l.new(sz.outputs[0],ec.inputs['Size'])
 # Remaining interface values drive actual distribution heights and row spacing.
 def sumsocket(socket,value,loc):
  op=n.new('ShaderNodeMath');op.operation='ADD';op.location=loc;op.inputs[1].default_value=value;l.new(socket,op.inputs[0]);return op.outputs[0]
 for nd in list(n):
  if nd.bl_idname=='GeometryNodeMeshLine':
   start=tuple(nd.inputs['Start Location'].default_value);offset=tuple(nd.inputs['Offset'].default_value)
   xyz=n.new('ShaderNodeCombineXYZ');xyz.location=(nd.location.x-180,nd.location.y+70);xyz.inputs['X'].default_value=start[0];xyz.inputs['Y'].default_value=start[1]
   l.new(sumsocket(inp.outputs['Floor Height'],start[2]-.96,(xyz.location.x-180,xyz.location.y)),xyz.inputs['Z']);l.new(xyz.outputs[0],nd.inputs['Start Location'])
   if nd.inputs['Count'].default_value==3:
    step=n.new('ShaderNodeCombineXYZ');step.location=(nd.location.x-180,nd.location.y-50);step.inputs['Y'].default_value=offset[1];l.new(inp.outputs['Wall Row Height'],step.inputs['Z']);l.new(step.outputs[0],nd.inputs['Offset'])
 # Realized source output preserves semantic face attribute used for material verification.
 l.new(join.outputs[0],out.inputs[0]);return g


def build07():
 me=bpy.data.meshes.new('GN host mesh');o=bpy.data.objects.new('PARAMETRIC | body and walls',me);bpy.context.collection.objects.link(o);track(o);m=o.modifiers.new('dimension-driven assembly','NODES');m.node_group=gn_group()
 # Custom source stock for wheels/shafts complements actual node-built body, not a GN label on a hand mesh.
 for s in [-1,1]:
  for x in [-1.08,1.01]:beam('parametric pinned upright',(x,s*.86,.84),(x,s*.90,1.81),.13,.14)
  beam('parametric main sill',(-1.25,s*.51,.83),(1.18,s*.51,.83),.16,.17,dark)
 shafts(-1.24,1.80,1.04,.84);wheels(.23,.75,.99,12 if not FIX else 8);hardware(2.22,1.42,.96,.65)
 EVIDENCE.append('Real node tree MeshLine -> Cube instances -> Realize -> Store Named Attribute(component_id) -> SetMaterial -> Join. Bed Length, Bed Width, Stock Thickness wired to geometry. Editable source keeps modifier; export evaluates it.')
 # Geometry Nodes generates no UVs. Add UV after evaluation for portable painted output, source stays procedural.



def uvparts(o):
 # UV by connected stock island after GN realization: no global projection across different boards.
 adjacency={v.index:set() for v in o.data.vertices}
 for ed in o.data.edges:
  a,b=ed.vertices;adjacency[a].add(b);adjacency[b].add(a)
 groups=[];remain=set(adjacency)
 while remain:
  seed=remain.pop();group={seed};stack=[seed]
  while stack:
   for q in adjacency[stack.pop()]:
    if q in remain:remain.remove(q);group.add(q);stack.append(q)
  groups.append(group)
 uvtrim(o,2)
 for j,group in enumerate(groups):
  co=[o.data.vertices[i].co for i in group];mn=[min(v[k] for v in co) for k in range(3)];mx=[max(v[k] for v in co) for k in range(3)];a,b=sorted(range(3),key=lambda k:mx[k]-mn[k],reverse=True)[:2]
  band=[1,2,0,1,2,1][j%6]
  for poly in o.data.polygons:
   if poly.vertices[0] not in group:continue
   poly.material_index=1 if abs(poly.normal[a])>.7 else 0
   for li in poly.loop_indices:
    v=o.data.vertices[o.data.loops[li].vertex_index].co;o.data.uv_layers.active.data[li].uv=(.02+.96*(v[a]-mn[a])/max(mx[a]-mn[a],1e-6),(band+.06+.88*(v[b]-mn[b])/max(mx[b]-mn[b],1e-6))/4)
 EVIDENCE.append({'GN_connected_stock_uv_islands':len(groups)})

def selectasset():
 bpy.ops.object.select_all(action='DESELECT')
 for o in ASSET:
  if o.name in bpy.data.objects:o.select_set(True)
 bpy.context.view_layer.objects.active=ASSET[0]

def joinasset(name):
 selectasset();bpy.ops.object.join();o=bpy.context.object;o.name=name;ASSET[:]=[o];return o

def smartuv(o):
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15,island_margin=.012);bpy.ops.object.mode_set(mode='OBJECT')

def bakepaint(o):
 # Source painted directional UVs retained as UV0; target unique UV1 provides a baked delivery atlas.
 target=o.data.uv_layers.new(name='painted_bake_atlas');o.data.uv_layers.active=target;smartuv(o)
 img=bpy.data.images.new(MID+' painted colour',width=1024,height=1024);img.filepath_raw=str(OUT/f'painted_baked_{STAGE}.png');img.file_format='PNG'
 for m in o.data.materials:
  m.use_nodes=True;node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=img;m.node_tree.nodes.active=node
 # Ensure source textures use source UV0 explicitly while destination active layer is atlas.
 for m in o.data.materials:
  for node in list(m.node_tree.nodes):
   if node.type=='TEX_IMAGE' and node.image!=img:
    uv=m.node_tree.nodes.new('ShaderNodeUVMap');uv.uv_map=o.data.uv_layers[0].name;m.node_tree.links.new(uv.outputs[0],node.inputs['Vector'])
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=1;scene.render.bake.use_pass_direct=False;scene.render.bake.use_pass_indirect=False;scene.render.bake.use_pass_color=True;scene.render.bake.margin=8
 bpy.ops.object.bake(type='DIFFUSE');img.save()
 bm=mat('painted baked delivery atlas',(180,130,67));tex=bm.node_tree.nodes.new('ShaderNodeTexImage');tex.image=img;bm.node_tree.links.new(tex.outputs['Color'],bm.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
 o.data.materials.clear();o.data.materials.append(bm)
 for p in o.data.polygons:p.material_index=0
 
 if FIX:
  for layer in list(o.data.uv_layers):
   if layer.name!='painted_bake_atlas':o.data.uv_layers.remove(layer)
  o.data.uv_layers.active=o.data.uv_layers.get('painted_bake_atlas');o.data.uv_layers.active.active_render=True
 else:
  o.data.uv_layers.remove(o.data.uv_layers[0]);o.data.uv_layers.active=o.data.uv_layers[0]
 EVIDENCE.append({'paint_bake':'Cycles DIFFUSE color only','resolution':1024,'source':'directional pigment trim -> unique smart UV atlas'})

def highlow():
 # Duplicate evaluated low cages. Remove existing small bevel strips would leave broken shape; instead low retains 2 segment bevel, high smooths further.
 low=joinasset('low cage cart')
 if FIX:
  for layer in list(low.data.uv_layers):low.data.uv_layers.remove(layer)
  low.data.uv_layers.new(name='unique_normal_atlas');low.data.uv_layers.active.active_render=True
 smartuv(low)
 high=low.copy();high.data=low.data.copy();bpy.context.collection.objects.link(high);high.name='HIGH | additional bevel relief'
 b=high.modifiers.new('high resolution bevel roll','BEVEL');b.width=.018 if FIX else .06;b.segments=5;apply(high,b)
 for p in high.data.polygons:p.use_smooth=True
 wn=high.modifiers.new('weighted high normals','WEIGHTED_NORMAL');wn.keep_sharp=True;apply(high,wn)
 img=bpy.data.images.new('real tangent high-low bake',width=1024,height=1024);img.colorspace_settings.name='Non-Color';img.filepath_raw=str(OUT/f'normal_{STAGE}.png');img.file_format='PNG'
 for m in low.data.materials:
  node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=img;m.node_tree.nodes.active=node
 bpy.ops.object.select_all(action='DESELECT');high.select_set(True);low.select_set(True);bpy.context.view_layer.objects.active=low
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=1;scene.render.bake.use_selected_to_active=True;scene.render.bake.max_ray_distance=.08;scene.render.bake.cage_extrusion=.08;scene.render.bake.margin=8
 bpy.ops.object.bake(type='NORMAL');img.save();scene.render.bake.use_selected_to_active=False
 # Smart UV invalidates source trim, so paint base color by simple warm pigments; normal still distinguishes roll.
 for i,m in enumerate(low.data.materials):
  for node in list(m.node_tree.nodes):
   if node.type=='TEX_IMAGE' and node.image!=img:m.node_tree.nodes.remove(node)
  p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rgb([(170,112,53),(193,144,79),(104,72,44),(72,71,61)][i%4]);tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=img;normal=m.node_tree.nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.6 if FIX else 1; m.node_tree.links.new(tex.outputs[0],normal.inputs[1]);m.node_tree.links.new(normal.outputs[0],p.inputs['Normal'])
 # Preserve high in a separate model-only archive, then remove from delivery.
 bpy.ops.object.select_all(action='DESELECT');high.select_set(True);bpy.context.view_layer.objects.active=high
 bpy.data.libraries.write(str(OUT/f'high_source_{STAGE}.blend'),{high},fake_user=True)
 high_polycount=len(high.data.polygons);bpy.data.objects.remove(high,do_unlink=True);selectasset();EVIDENCE.append({'actual_normal_bake':str(img.filepath_raw),'high_bevel_width':.018 if FIX else .06,'high_segments':5,'low_polygons':len(low.data.polygons),'high_polygons':high_polycount})


getattr(sys.modules[__name__],'build'+MID[1:])()
# Source stays fully editable, no preview objects. M07 source preserves live Geometry Nodes.
selectasset();bpy.ops.wm.save_as_mainfile(filepath=str(OUT/f'source_{STAGE}.blend'))
if MID=='M07':
 for o in list(ASSET):
  for m in list(o.modifiers):apply(o,m)
  if 'PARAMETRIC' in o.name:
   if FIX:uvparts(o)
   else:uvtrim(o,2)
   bevel(o,.025,2)
if MID=='M04':highlow()
if MID=='M01':
 o=joinasset('reference-built painted cargo cart');bakepaint(o)
# Normalize display size by whole model bounds to common longest dimension 5.0. This is a comparison-only size convention also used in export.
allco=[o.matrix_world@v.co for o in ASSET for v in o.data.vertices];mn=Vector([min(v[i] for v in allco) for i in range(3)]);mx=Vector([max(v[i] for v in allco) for i in range(3)]);factor=5/(mx.x-mn.x);center=(mn+mx)/2;center.z=mn.z
for o in ASSET:
 o.location=(o.location-center)*factor;o.scale*=factor
selectasset();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
for im in bpy.data.images:
 if im.source=='FILE':
  try:im.pack()
  except:pass
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/f'cart_{STAGE}.blend'))
selectasset();bpy.ops.export_scene.gltf(filepath=str(OUT/f'cart_{STAGE}.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False)
# Verify binary contract independently without import disturbing scene.
data=(OUT/f'cart_{STAGE}.glb').read_bytes();import struct
jsn=json.loads(data[20:20+struct.unpack_from('<I',data,12)[0]].decode().rstrip(' \x00'));report={'file':f'cart_{STAGE}.glb','bytes':len(data),'meshes':len(jsn.get('meshes',[])),'materials':len(jsn.get('materials',[])),'images':len(jsn.get('images',[])),'cameras':len(jsn.get('cameras',[])),'light_extension':any('KHR_lights_punctual' in n.get('extensions',{}) for n in jsn.get('nodes',[])),'polygons':sum(len(o.data.polygons) for o in ASSET),'bounds_before_normalization':[list(mn),list(mx)],'normalization_scale':factor,'method_evidence':EVIDENCE}
(OUT/f'verification_{STAGE}.json').write_text(json.dumps(report,indent=2))
# Fixed review rig. Identical whole-model 5 unit size, same camera/light, views.
sys.path.insert(0,str(ROOT.parent.parent/'rock_painterly_v2'));import review_rig
cam=review_rig.setup((720,600),6.35,(0,0,1.03));bpy.context.scene.cycles.samples=12
views={'front':(-4.5,-6.6,3.5),'back':(4.5,6.6,3.5),'side':(0,-7,2.2),'end':(6,0,2.7)}
for name,loc in (views.items() if FIX else [('front',views['front'])]):review_rig.shot(cam,OUT/f'{STAGE}_{name}.png',loc,(0,0,1.03))
print('METHOD_COMPLETE',MID,STAGE,json.dumps({k:v for k,v in report.items() if k!='method_evidence'}))

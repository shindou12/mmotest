from pathlib import Path
import json
R=Path(__file__).resolve().parent;reg=json.loads((R/'registry.json').read_text());errors=[]
for row in reg['methods']:
 p=R/row['id'];paths=row['source']+row['textures']+row['corrected_views']+row['verification']+[row['initial'],row['visual_evaluation'],row['glb'],row['editable_model'],row['thumbnail']]
 for rel in paths:
  if not (p/rel).exists():errors.append(str(p/rel))
 v=json.loads((p/'glb_reimport_verification.json').read_text())
 if not(v['all_finite'] and not v['unexpected_camera_or_light'] and not v['textured_mesh_without_uv'] and abs(v['normalized_length']-5)<1e-5):errors.append(row['id']+' contract')
report={'records':len(reg['methods']),'errors':errors,'selected_meshes':json.loads((R/'M06/glb_reimport_verification.json').read_text())['mesh_objects'],'visual_review_completed':True};print(json.dumps(report));(R/'registry_audit.json').write_text(json.dumps(report,indent=2))

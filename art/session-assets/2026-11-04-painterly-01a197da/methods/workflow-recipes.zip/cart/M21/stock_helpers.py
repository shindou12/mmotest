"""Cargo cart method lab. Each build begins from an empty scene, no previous mesh import.
Invocation: blender -b --python build_cart.py -- M01 initial|corrected
"""
import bpy, math, random, sys, pathlib, json, shutil
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parent
MID='M21';STAGE=sys.argv[-1] if sys.argv[-1] in ('initial','corrected') else 'initial'
OUT=ROOT;FIX=True;random.seed(121)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for m in list(bpy.data.materials):bpy.data.materials.remove(m)
ASSET=[];EVIDENCE=[]
def rgb(t):
 return tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in [x/255 for x in t])+(1,)
def mat(name,col,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=rgb(col);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rgb(col);p.inputs['Roughness'].default_value=.8;p.inputs['Metallic'].default_value=metal;return m
metal=mat('quiet blue-brown iron',(69,70,61),.35)
end=mat('warm endgrain',(184,134,72));dark=mat('recessed wood',(111,72,39));light=mat('fresh worn facets',(207,158,88))
wood=bpy.data.materials.new('painted directional oak');wood.use_nodes=True
nt=wood.node_tree;p=nt.nodes.get('Principled BSDF');p.inputs['Roughness'].default_value=.86
tex=nt.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(ROOT/'wood_trim.png' if MID=='M06' and not FIX else OUT/'wood_trim.png'));nt.links.new(tex.outputs['Color'],p.inputs['Base Color'])

def track(o):
 ASSET.append(o);return o

def apply(o,m):
 bpy.context.view_layer.objects.active=o
 try:bpy.ops.object.modifier_apply(modifier=m.name)
 except Exception as e:EVIDENCE.append(str(e))

def bevel(o,width=.028,segments=2):
 m=o.modifiers.new('hand softened broad corners','BEVEL');m.width=width;m.segments=segments;apply(o,m)
 # flat polygon normals preserve facets; modest bevel strips catch light
 return o

def uvtrim(o,band=None):
 if not o.data.uv_layers:o.data.uv_layers.new(name='directional_paint')
 band=random.randrange(4) if band is None else band
 coords=[v.co for v in o.data.vertices];mn=[min(v[i] for v in coords) for i in range(3)];mx=[max(v[i] for v in coords) for i in range(3)]
 order=sorted(range(3),key=lambda i:mx[i]-mn[i],reverse=True);a,b=order[:2]
 for poly in o.data.polygons:
  # align every long face with grain; minor end faces are quieter flat colour
  if abs(poly.normal[a])>.7:poly.material_index=1
  for li in poly.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co
   u=(co[a]-mn[a])/max(mx[a]-mn[a],1e-5)
   v=(co[b]-mn[b])/max(mx[b]-mn[b],1e-5)
   o.data.uv_layers.active.data[li].uv=(.02+.96*u,(band+.06+.88*v)/4)
 o.data.materials.clear();o.data.materials.append(wood);o.data.materials.append(end)

def box(name,loc,dim,material=wood,bev=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=dim
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if material==wood:uvtrim(o)
 else:o.data.materials.append(material)
 if bev:bevel(o,bev)
 return track(o)

def beam(name,a,b,width,depth=None,material=wood,bev=.025):
 a,b=Vector(a),Vector(b);v=b-a
 o=box(name,(a+b)/2,(v.length,width,depth or width),material,bev)
 o.rotation_euler=v.to_track_quat('X','Z').to_euler();return o

def extrude_polygon(name,pts,depth,axis='Y',offset=0,material=wood):
 # Explicit silhouette polygon extruded normal to its drawing plane.
 verts=[]
 for s in [-1,1]:
  for a,b in pts:verts.append((a,offset+s*depth/2,b) if axis=='Y' else (offset+s*depth/2,a,b))
 n=len(pts);faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o)
 if material==wood:uvtrim(o)
 else:me.materials.append(material)
 bevel(o,.025,2);return track(o)

def ring(name,center,radius,width,depth,material=wood,n=48):
 # Closed annular profile swept around Y, coarse irregular felloes.
 cx,cy,cz=center;verts=[]
 for y in [-depth/2,depth/2]:
  for r in [radius-width,radius]:
   for i in range(n):
    a=i*2*math.pi/n; rr=r*(1+.004*math.sin(i*3.1));verts.append((cx+rr*math.cos(a),cy+y,cz+rr*math.sin(a)))
 faces=[]
 for i in range(n):
  j=(i+1)%n
  faces.extend([(i,j,n+j,n+i),(2*n+i,3*n+i,3*n+j,2*n+j),(i,2*n+i,2*n+j,j),(n+i,n+j,3*n+j,3*n+i)])
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o)
 if material==wood:
  uvtrim(o,2)
  if MID=='M06' and FIX:
   for poly in me.polygons:
    angles=[math.atan2(me.vertices[me.loops[li].vertex_index].co.z-cz,me.vertices[me.loops[li].vertex_index].co.x-cx)%(2*math.pi) for li in poly.loop_indices]
    if max(angles)-min(angles)>math.pi:angles=[a+2*math.pi if a<math.pi else a for a in angles]
    band=[1,1,2,1,0,1,1,2][int(sum(angles)/len(angles)/(2*math.pi)*8)%8]
    poly.material_index=0
    for li,ang in zip(poly.loop_indices,angles):
     v=me.vertices[me.loops[li].vertex_index].co;rad=math.hypot(v.x-cx,v.z-cz);t=(rad-(radius-width))/width if abs(poly.normal.y)>.6 else (v.y-cy+depth/2)/depth
     me.uv_layers.active.data[li].uv=(ang/(2*math.pi)*3,(band+.08+.84*t)/4)
 else:me.materials.append(material)
 bevel(o,.015,2);return track(o)

def cylinder(name,center,radius,depth,material):
 bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=radius,depth=depth,location=center,rotation=(math.pi/2,0,0));o=bpy.context.object;o.name=name;o.data.materials.append(material);bevel(o,.016,2);return track(o)

def wheels(cx=.20,r=.72,spacing=.94,count=10,thin=False):
 for side in [-1,1]:
  y=side*spacing;cz=r+.025
  ring('wide oak felloe', (cx,y,cz),r,.105,.16 if not thin else .09)
  ring('restrained outer iron tire',(cx,y,cz),r+.023,.028,.185 if not thin else .11,metal)
  for i in range(count):
   a=i*2*math.pi/count+.05
   a0=(cx+.13*math.cos(a),y,cz+.13*math.sin(a));b0=(cx+(r-.075)*math.cos(a),y,cz+(r-.075)*math.sin(a))
   sp=beam('radial tapered oak spoke',a0,b0,.075 if FIX else .105,.105,bev=.014)
   if MID=='M06' and FIX:
    for vert in sp.data.vertices:
     taper=1.18-.34*(vert.co.x/(Vector(b0)-Vector(a0)).length+.5);vert.co.y*=taper;vert.co.z*=taper
  cylinder('large warm carved hub',(cx,y,cz),.18,.30,wood)
  # UV map cylinder after adding wood
  uvtrim(ASSET[-1],1)
  cylinder('small quiet axle cap',(cx,y+side*.175,cz),.092,.055,metal)
 beam('load-bearing axle',(cx,-spacing-.18,r+.025),(cx,spacing+.18,r+.025),.16,.16,dark)

def standard_body(length=2.0,width=1.35,floorz=.93,rows=3,wall=.65,flare=.12,irregular=False):
 # Conventional blockout driven by the measured reference, not imported geometry.
 for i in range(6):
  y=-width/2+(i+.5)*width/6
  box('wide floor plank',(-.08,y,floorz),(length,width/6-.016,.105),bev=.018)
 for side in [-1,1]:
  for j in range(rows):
   z=floorz+.15+(j+.5)*wall/rows;y=side*(width/2+.02+flare*(j+1)/rows)
   o=box('broad sidewall plank',(-.08,y,z),(length+.13,.095,wall/rows-.016),bev=.027)
   if irregular:o.rotation_euler.y=math.radians(random.uniform(-1.3,1.3));o.rotation_euler.z=math.radians(side*1.2)
  for x in [-length/2+.02,length/2-.16]:
   beam('upright pinned wall stake',(x,side*(width/2+.10),floorz-.10),(x,side*(width/2+flare+.10),floorz+wall+.22),.13,.14)
 for x in [-length/2-.03,length/2-.13]:
  for j in range(rows):
   z=floorz+.15+(j+.5)*wall/rows
   o=box('broad endwall plank',(x,0,z),(.10,width+.12+flare*1.5,wall/rows-.016),bev=.023)
 for y in [-width*.38,width*.38]:
  beam('subframe longitudinal sill',(-length/2-.15,y,floorz-.10),(length/2+.03,y,floorz-.10),.16,.18,dark)


def shafts(front=-1.1,length=1.8,width=.95,z=.85,curved=False):
 for side in [-1,1]:
  if curved:
   curved_board('bent ash pulling shaft',[(front+.12,side*width/2,z),(front-.5,side*(width/2+.03),z+.04),(front-length,side*(width/2+.13),z-.08)],.10,.11)
  else:
   beam('long forward pulling shaft',(front+.10,side*width/2,z),(front-length,side*(width/2+.12),z-.13),.105,.125)
  box('dark shaft grip collar',(front-length+.14,side*(width/2+(.12 if curved and FIX else .11)),z-(.071 if curved and FIX else .11)),(.06,.125,.14),metal,.012)


def hardware(length=2,width=1.35,floorz=.93,wall=.65):
 for x in [-length/2+.02,length/2-.16]:
  for side in [-1,1]:
   y=side*(width/2+.12)
   # Tiny fastening plates only at load-bearing sill, not on every plank.
   box('sill joint iron shoe',(x,y,floorz+.015),(.19,.035,.15),metal,.012)
   cylinder('joint pin',(x,y+side*.027,floorz+.015),.035,.035,metal)

def curved_board(name,points,w,h):
 # Actual Bezier guide + Curve modifier, retained source in separate construction blend.
 length=sum((Vector(b)-Vector(a)).length for a,b in zip(points,points[1:]));origin=Vector(points[0]);direction=(Vector(points[-1])-origin).normalized()
 # A local X curve: coordinates relative to root, with main direction usually X.
 cu=bpy.data.curves.new(name+' shaping guide','CURVE');cu.dimensions='3D';sp=cu.splines.new('BEZIER');sp.bezier_points.add(len(points)-1)
 for bp,pnt in zip(sp.bezier_points,points):bp.co=Vector(pnt)-origin;bp.handle_left_type='AUTO';bp.handle_right_type='AUTO'
 c=bpy.data.objects.new(name+' curve',cu);bpy.context.collection.objects.link(c);c.location=origin
 # Main orientation can decrease X: reverse points to ensure +X deformation.
 if points[-1][0]<points[0][0]:
  bpy.data.objects.remove(c,do_unlink=True);return curved_board(name,list(reversed(points)),w,h)
 ln=points[-1][0]-points[0][0];N=14;verts=[]
 for i in range(N+1):
  for y,z in [(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)]:
   if MID=='M06' and FIX:
    t=i/N;z*=1+.045*math.sin(t*11+len(ASSET)*.7)
    if z>0 and 'side' in name and i in [8,9]:z-=.028 if len(ASSET)%3==0 else .006
    if z<0 and i in [1,2] and 'side' in name:z+=.012
   verts.append((ln*i/N,y,z))
 faces=[(3,2,1,0),(4*N,4*N+1,4*N+2,4*N+3)]
 for i in range(N):
  for j in range(4):faces.append((4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j))
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.location=origin;uvtrim(o);track(o)
 m=o.modifiers.new('curve-designed warp','CURVE');m.object=c;m.deform_axis='POS_X';apply(o,m);bevel(o,.018,2)
 # Guide preserved in construction archive via point coordinates JSON; no guide object in model export.
 EVIDENCE.append({'curve':name,'points':points});bpy.data.objects.remove(c,do_unlink=True);return o



def selectasset():
 bpy.ops.object.select_all(action='DESELECT')
 for o in ASSET:
  if o.name in bpy.data.objects:o.select_set(True)
 bpy.context.view_layer.objects.active=ASSET[0]

def joinasset(name):
 selectasset();bpy.ops.object.join();o=bpy.context.object;o.name=name;ASSET[:]=[o];return o

def smartuv(o):
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15,island_margin=.012);bpy.ops.object.mode_set(mode='OBJECT')

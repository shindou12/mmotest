from PIL import Image,ImageDraw
from pathlib import Path
import random,math
p=Path(__file__).resolve().parent
random.seed(2121);im=Image.new('RGB',(1024,1024));d=ImageDraw.Draw(im)
colors=[(151,100,54),(173,121,64),(195,146,80),(128,85,50)]
for b,c in enumerate(colors):
 y0=b*256;d.rectangle((0,y0,1024,y0+256),fill=c)
 # wide painted masses with rough, deliberately stepped brush silhouettes
 for j in range(16):
  x=random.randint(-250,850);y=y0+random.randint(15,245);ln=random.randint(200,650);w=random.randint(12,42);v=random.choice([-20,-13,10,18,24]);col=tuple(max(0,min(255,a+v)) for a in c)
  pts=[(x,y),(x+ln*.13,y-w*.25),(x+ln*.25,y-w*.8),(x+ln*.42,y-w*.65),(x+ln*.61,y-w*.85),(x+ln*.85,y-w*.3),(x+ln,y),(x+ln*.82,y+w*.2),(x+ln*.70,y+w*.63),(x+ln*.43,y+w*.5),(x+ln*.28,y+w*.8),(x+ln*.11,y+w*.25)]
  d.polygon(pts,fill=col)
 # only three long dark fault strokes, broad shape takes priority
 for j in range(3):
  x=random.randrange(50,550);y=y0+45+j*69;ln=random.randrange(220,520)
  d.line([(x+k*ln/10,y+math.sin(k*.6+j)*3) for k in range(11)],fill=tuple(a-30 for a in c),width=3)
 # local pale rubbed patch, covers only part of the board, not an all-edge highlight
 d.polygon([(50,y0+18),(270,y0+10),(610,y0+23),(580,y0+34),(375,y0+29),(170,y0+40)],fill=tuple(min(255,a+30) for a in c))
 cx=750 if b%2==0 else 370;cy=y0+145
 for rx,ry in [(55,14),(31,9),(12,4)]:d.ellipse((cx-rx,cy-ry,cx+rx,cy+ry),outline=tuple(a-34 for a in c),width=3)
im.save(p/'wood_trim.png');im.save(p/'broad_pigment_source.png')

import bpy,sys,json,struct
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from unlit_material import build
import review_rig
bpy.ops.wm.open_mainfile(filepath=str(R/'cart_unlit_initial.blend'))
o=next(o for o in bpy.context.scene.objects if o.type=='MESH')
image=next(n.image for n in o.data.materials[0].node_tree.nodes if n.type=='TEX_IMAGE')
o.data.materials.clear();o.data.materials.append(build(bpy,image))
for p in o.data.polygons:p.material_index=0
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
bpy.ops.wm.save_as_mainfile(filepath=str(R/'cart_unlit_initial.blend'))
bpy.ops.export_scene.gltf(filepath=str(R/'cart_unlit_initial.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False)
b=(R/'cart_unlit_initial.glb').read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]])
native=all('KHR_materials_unlit' in m.get('extensions',{}) for m in j['materials']);assert native
report=json.loads((R/'failed_emission_only_export.json').read_text());report.update(native_export_unlit=native,extensionsUsed=j.get('extensionsUsed'),materials=j['materials'],export_fix='Native camera-ray Mix Shader pattern. Failed initial emission-only report retained separately.')
(R/'verification_initial.json').write_text(json.dumps(report,indent=2))
cam=review_rig.setup((720,600),6.35,(0,0,1.03));bpy.context.scene.cycles.samples=16
for name,loc in {'front':(-4.5,-6.6,3.5),'back':(4.5,6.6,3.5),'side':(0,-14,3.37),'end':(6,0,2.7)}.items():review_rig.shot(cam,R/f'initial_{name}.png',loc,(0,0,1.03))
print('M21_INITIAL_REPAIRED')

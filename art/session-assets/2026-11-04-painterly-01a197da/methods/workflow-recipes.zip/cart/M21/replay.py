"""M21: fresh stock assembly -> real diffuse direct/indirect bake -> AO -> native glTF unlit.
blender -b --python replay.py -- initial|corrected
No pre-existing mesh is imported. Regular-lit model is retained for comparison.
"""
import sys,pathlib,math,json,struct
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from stock_helpers import *
import review_rig
STAGE=sys.argv[-1] if sys.argv[-1] in ('initial','corrected') else 'initial';COR=STAGE=='corrected'
# Fresh variant: two broad wall courses + narrow protective rail, subtly bowed stock.
W=1.53;L=2.36;fz=.98
for j in range(5):
 y=-W/2+(j+.5)*W/5
 curved_board('fresh broad load floor',[(-1.20,y,fz),(-.25,y+.009,fz+.01),(1.13,y,fz-.006)],W/5-.016,.12)
for side in [-1,1]:
 for j,(z,h,yy) in enumerate([(1.18,.30,.805),(1.485,.265,.87),(1.705,.105,.91)]):
  y=side*yy
  curved_board('new graduated side course '+str(j),[(-1.24,y,z),(-.42,y+side*.018,z+.012*(j-1)),(.45,y+side*.012,z-.014),(1.15,y,z+.008)],.115,h)
 for x in [-1.14,1.075]:beam('new flared corner load stake',(x,side*.84,.86),(x-.022,side*1.00,1.815),.16,.15)
 beam('new heavy longitudinal sill',(-1.30,side*.52,.85),(1.23,side*.52,.85),.18,.19,dark)
for x in [-1.20,1.15]:
 for j,(z,h,ww) in enumerate([(1.18,.30,.81),(1.485,.265,.875)]):
  pts=[(-ww,z-h/2),(ww,z-h/2+.008),(ww,z+h/2-.016),(.38,z+h/2+.004),(-.35,z+h/2-.009),(-ww,z+h/2)]
  extrude_polygon('new broad gate profile',pts,.115,'X',x)
for x in [-1.00,.91]:beam('new transverse bed bearer',(x,-.90,.89),(x,.90,.89),.20,.17,dark)
shafts(-1.31,1.94,1.10,.89,True);wheels(.31,.77,1.04,10)
# Keep hardware limited to the lower stake/shaft connections.
for x in [-1.14,1.075]:
 for side in [-1,1]:
  y=side*.92;box('single pinned lower joint',(x,y,.98),(.18,.035,.13),metal,.01);cylinder('quiet joint pin',(x,y+side*.025,.98),.035,.025,metal)
# Normalize precisely like comparison lane.
co=[o.matrix_world@v.co for o in ASSET for v in o.data.vertices];mn=Vector([min(v[i] for v in co) for i in range(3)]);mx=Vector([max(v[i] for v in co) for i in range(3)]);factor=5/(mx.x-mn.x);center=(mn+mx)/2;center.z=mn.z
for o in ASSET:o.location=(o.location-center)*factor;o.scale*=factor
selectasset();bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# Harmonize authoritative render UV before joining; source pigment remains separate from bake atlas.
for o in ASSET:
 if not o.data.uv_layers:o.data.uv_layers.new(name='stock_paint')
 active=next((v for v in o.data.uv_layers if v.active_render),o.data.uv_layers.active)
 for layer in list(o.data.uv_layers):
  if layer!=active:o.data.uv_layers.remove(layer)
 active.name='stock_paint';o.data.uv_layers.active=active;active.active_render=True
cart=joinasset('M21 | fresh cart for designed-light bake')
for im in bpy.data.images:
 if im.source=='FILE':im.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(R/'regular_lit_source.blend'))
selectasset();bpy.ops.export_scene.gltf(filepath=str(R/'regular_lit.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False)
cam=review_rig.setup((720,600),6.35,(0,0,1.03));bpy.context.scene.cycles.samples=16
views={'front':(-4.5,-6.6,3.5),'back':(4.5,6.6,3.5),'side':(0,-14,3.37),'end':(6,0,2.7)}
if not COR:
 for name,loc in views.items():review_rig.shot(cam,R/f'regular_lit_{name}.png',loc,(0,0,1.03))
# Remove every preview object, including floor, before baking. Bounce/AO come only from the asset.
for o in list(bpy.context.scene.objects):
 if o!=cart:bpy.data.objects.remove(o,do_unlink=True)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=40;scene.cycles.use_denoising=False
scene.world.use_nodes=True;bg=scene.world.node_tree.nodes['Background'];bg.inputs[0].default_value=(.28,.33,.42,1);bg.inputs[1].default_value=.22 if COR else 2.0
lightsetup=[]
def area(name,loc,energy,size,color):
 d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape='DISK';d.size=size;d.color=color;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler();lightsetup.append({'name':name,'location':loc,'energy':energy,'size':size,'color':color})
if COR:
 area('BAKE | warm shaped key',(-3,-4,6),650,3.0,(1,.83,.61));area('BAKE | cool restrained fill',(3,2,4),130,4.5,(.61,.76,1));area('BAKE | soft top return',(-1,3,6),100,4,(1,.89,.68))
else:
 area('BAKE | excessively broad bright key',(-3,-4,6),1700,6,(1,.95,.85));area('BAKE | excessively broad fill',(3,2,4),1100,6,(.85,.92,1))
# New non-overlapping UV atlas; explicit stock UV remains shader source.
cart.data.uv_layers.new(name='designed_light_atlas');cart.data.uv_layers.active=cart.data.uv_layers['designed_light_atlas'];cart.data.uv_layers.active.active_render=True;smartuv(cart)
size=2048;image=bpy.data.images.new('M21 real diffuse radiance '+STAGE,width=size,height=size,float_buffer=True);image.filepath_raw=str(R/f'diffuse_direct_indirect_{STAGE}.png');image.file_format='PNG'
# DIFFUSE excludes metallic reflection: the first corrected test produced black wheel bands.
# For this deliberately matte unlit output, bake a diffuse approximation of painted iron.
if COR:
 for material in cart.data.materials:
  for shader in material.node_tree.nodes:
   if shader.type=='BSDF_PRINCIPLED':shader.inputs['Metallic'].default_value=0
targetnodes=[]
for m in cart.data.materials:
 m.use_nodes=True
 for node in list(m.node_tree.nodes):
  if node.type=='TEX_IMAGE':
   uv=m.node_tree.nodes.new('ShaderNodeUVMap');uv.uv_map='stock_paint';m.node_tree.links.new(uv.outputs[0],node.inputs['Vector'])
 node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=image;m.node_tree.nodes.active=node;targetnodes.append((m,node))
selectasset();scene.render.bake.use_selected_to_active=False;scene.render.bake.use_pass_direct=True;scene.render.bake.use_pass_indirect=True;scene.render.bake.use_pass_color=True;scene.render.bake.margin=12
bpy.ops.object.bake(type='DIFFUSE');image.save()
ao=bpy.data.images.new('M21 actual self AO '+STAGE,width=size,height=size,float_buffer=True);ao.filepath_raw=str(R/f'ao_{STAGE}.png');ao.file_format='PNG';scene.world.color=(.8,.8,.8)
for m,n in targetnodes:n.image=ao;m.node_tree.nodes.active=n
bpy.ops.object.bake(type='AO');ao.save()
# AO is deliberately restrained. All color and directional light originate in the actual diffuse bake.
import numpy as np
pixels=np.empty(size*size*4,dtype=np.float32);occlusion=np.empty_like(pixels);image.pixels.foreach_get(pixels);ao.pixels.foreach_get(occlusion);p=pixels.reshape((-1,4));a=occlusion.reshape((-1,4))[:,0]
strength=.14 if COR else .05;p[:,:3]*=((1-strength)+strength*a)[:,None];p[:,3]=1
final=bpy.data.images.new('M21 designed light '+STAGE,width=size,height=size,float_buffer=True);final.pixels.foreach_set(p.reshape(-1));final.filepath_raw=str(R/f'baked_light_{STAGE}.png');final.file_format='PNG';final.save();final.pack()
# Native camera-ray/emission pattern exports KHR_materials_unlit.
from unlit_material import build
u=build(bpy,final);cart.data.materials.clear();cart.data.materials.append(u)
for poly in cart.data.polygons:poly.material_index=0
for layer in list(cart.data.uv_layers):
 if layer.name!='designed_light_atlas':cart.data.uv_layers.remove(layer)
cart.data.uv_layers.active=cart.data.uv_layers['designed_light_atlas'];cart.data.uv_layers.active.active_render=True
for o in list(bpy.context.scene.objects):
 if o!=cart:bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/f'cart_unlit_{STAGE}.blend'))
selectasset();bpy.ops.export_scene.gltf(filepath=str(R/f'cart_unlit_{STAGE}.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False)
b=(R/f'cart_unlit_{STAGE}.glb').read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]].decode().rstrip(' \x00'));native=all('KHR_materials_unlit' in m.get('extensions',{}) for m in j['materials'])
report={'method':'M21','stage':STAGE,'new_geometry':'Fresh five-floorboard, two broad wall courses + narrow rail cart, assembled only from helper primitives/curves; no imported prior cart mesh.','bake_type':'DIFFUSE','passes':{'color':True,'direct':True,'indirect':True},'self_AO_bake':True,'AO_multiply_strength':strength,'floor_present_during_bake':False,'matte_metal_approximation':COR,'bake_samples':40,'world_strength':.22 if COR else 2.0,'lighting':lightsetup,'atlas_size':size,'native_export_unlit':native,'extensionsUsed':j.get('extensionsUsed',[]),'materials':j['materials'],'mesh_count':len(j['meshes']),'bytes':len(b),'limitation':'Directional lighting and self-shadow are fixed into texture. Asset should keep its designed orientation/light context; runtime light changes do not relight it.'}
(R/f'verification_{STAGE}.json').write_text(json.dumps(report,indent=2));print('NATIVE_UNLIT',native)
if not native:raise RuntimeError('Native export did not create KHR_materials_unlit; preserve evidence and inspect before patching')
cam=review_rig.setup((720,600),6.35,(0,0,1.03));scene.cycles.samples=16
for name,loc in views.items():review_rig.shot(cam,R/f'{STAGE}_{name}.png',loc,(0,0,1.03))
print('M21_COMPLETE',STAGE)


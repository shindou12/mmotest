import bpy,math
from mathutils import Vector

def rgb(h):
    a=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in a)+(1,)

def setup(res=(900,740),scale=3.25,target=(0,0,.66)):
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=20
    scene.render.resolution_x=res[0];scene.render.resolution_y=res[1];scene.render.resolution_percentage=100
    scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
    scene.world.use_nodes=True;bg=scene.world.node_tree.nodes['Background'];bg.inputs[0].default_value=(.24,.27,.30,1);bg.inputs[1].default_value=.45
    bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.012));floor=bpy.context.object;floor.name='PREVIEW ONLY | ground'
    m=bpy.data.materials.new('PREVIEW | charcoal');m.use_nodes=True;m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=rgb('303B3D');m.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=1;floor.data.materials.append(m)
    def area(name,loc,energy,size,color):
        d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape='DISK';d.size=size;d.color=color
        o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    area('PREVIEW | key',(-3,-4,6),300,4,(1,.95,.86));area('PREVIEW | fill',(4,-1,4),110,5,(.81,.90,1));area('PREVIEW | rim',(-1,4,5),200,3,(1,.95,.86))
    d=bpy.data.cameras.new('PREVIEW | camera');cam=bpy.data.objects.new('PREVIEW | camera',d);scene.collection.objects.link(cam);scene.camera=cam;d.type='ORTHO';d.ortho_scale=scale
    return cam

def shot(cam,path,loc=(3.5,-6.4,3.2),target=(0,0,.66)):
    cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    bpy.context.scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)

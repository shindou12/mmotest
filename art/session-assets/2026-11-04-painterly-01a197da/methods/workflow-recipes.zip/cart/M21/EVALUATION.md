# M21 — authored light bake

Fresh geometry was built from empty scene with shared primitive/curve helpers. DIFFUSE color/direct/indirect and self-AO are real Cycles image bakes; the floor was removed before baking. The initial bright world and broad key washed out the timber. The corrected key/fill/ambient restore its broad color masses. The first corrected bake exposed nearly black metallic wheel bands; a diffuse matte approximation and weaker AO were tested, but the bands remain too dark for the chosen style.

Emission alone exported emissive PBR, not unlit. This failed export report is retained. The native camera-ray Mix Shader pattern found in the installed Khronos exporter now emits KHR_materials_unlit without patching JSON. The actual GLB was imported into a fresh scene. Its fixed color is preserved; runtime illumination cannot relight it. Source/reimport render differences also include secondary-ray/floor response, so this is not a claim of exact shading equivalence.

Front and back images confirm the workflow works but does not outperform M06. Keep as a comparative experiment. No black wheel, fixed light, or failed exporter evidence is hidden.

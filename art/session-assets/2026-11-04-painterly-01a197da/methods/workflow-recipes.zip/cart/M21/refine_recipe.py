from pathlib import Path
import shutil
R=Path(__file__).resolve().parent
for name in ['corrected_front.png','corrected_back.png','cart_unlit_corrected.glb','verification_corrected.json']:
 shutil.copy2(R/name,R/('black_metal_'+name))
p=R/'replay.py';s=p.read_text(encoding='utf-8-sig')
s=s.replace('targetnodes=[]','''# DIFFUSE excludes metallic reflection: the first corrected test produced black wheel bands.
# For this deliberately matte unlit output, bake a diffuse approximation of painted iron.
if COR:
 for material in cart.data.materials:
  for shader in material.node_tree.nodes:
   if shader.type=='BSDF_PRINCIPLED':shader.inputs['Metallic'].default_value=0
targetnodes=[]''')
s=s.replace('strength=.25 if COR else .05','strength=.14 if COR else .05')
s=s.replace("'floor_present_during_bake':False","'floor_present_during_bake':False,'matte_metal_approximation':COR")
p.write_text(s)

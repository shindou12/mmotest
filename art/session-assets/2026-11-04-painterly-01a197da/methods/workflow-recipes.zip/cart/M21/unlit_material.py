def build(bpy, image):
    # Supported native glTF exporter light-path pattern, unlit.py in Blender 5.2.
    m=bpy.data.materials.new('M21 | authored light | native unlit');m.use_nodes=True
    n=m.node_tree.nodes;l=m.node_tree.links;n.clear()
    out=n.new('ShaderNodeOutputMaterial');mix=n.new('ShaderNodeMixShader')
    ray=n.new('ShaderNodeLightPath');em=n.new('ShaderNodeEmission');tex=n.new('ShaderNodeTexImage');tex.image=image
    diffuse=n.new('ShaderNodeBsdfDiffuse')
    l.new(tex.outputs['Color'],em.inputs['Color']);l.new(tex.outputs['Color'],diffuse.inputs['Color'])
    l.new(ray.outputs['Is Camera Ray'],mix.inputs[0]);l.new(diffuse.outputs[0],mix.inputs[1]);l.new(em.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs['Surface'])
    return m

import bpy,pathlib,json,shutil
R=pathlib.Path(__file__).resolve().parent;P=R/'M06';A=P/'runtime_prejoin_archive';A.mkdir(exist_ok=True)
for n in ['cart_corrected.glb','verification_corrected.json']:
 if not (A/n).exists():shutil.copy2(P/n,A/n)
bpy.ops.wm.open_mainfile(filepath=str(P/'cart_corrected.blend'))
assets=[o for o in bpy.context.scene.objects if o.type=='MESH'];bpy.ops.object.select_all(action='DESELECT')
for o in assets:
 o.select_set(True)
 # Preserve the exact render UV per object before join combines layer names.
 if o.data.uv_layers:
  active=next((uv for uv in o.data.uv_layers if uv.active_render),o.data.uv_layers.active)
  for uv in list(o.data.uv_layers):
   if uv!=active:o.data.uv_layers.remove(uv)
  active.name='paint_uv';o.data.uv_layers.active=active;active.active_render=True
bpy.context.view_layer.objects.active=assets[0];bpy.ops.object.join();o=bpy.context.object;o.name='Cargo cart | aged curved oak'
# Join deduplicates identical material datablocks; remove unreferenced slots conservatively.
bpy.ops.object.material_slot_remove_unused();print('RUNTIME_MATERIALS',[m.name for m in o.data.materials]);before_count=len(assets)
bpy.ops.wm.save_as_mainfile(filepath=str(P/'cart_runtime.blend'))
bpy.ops.export_scene.gltf(filepath=str(P/'cart_corrected.glb'),export_format='GLB',use_selection=True,export_apply=True,export_cameras=False,export_lights=False)
# Binary verification is supplemented by visual empty-scene reimport next.
import struct
b=(P/'cart_corrected.glb').read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]].decode().rstrip(' \x00'))
proof={'original_mesh_objects':before_count,'runtime_mesh_objects':len(j['meshes']),'materials':[m['name'] for m in j['materials']],'images':len(j.get('images',[])),'bytes':len(b),'source_preserved':'cart_corrected.blend','runtime_source':'cart_runtime.blend','export':'cart_corrected.glb','polygons':len(o.data.polygons)}
(P/'runtime_optimization.json').write_text(json.dumps(proof,indent=2))
v=json.loads((P/'verification_corrected.json').read_text());v.update({'meshes':len(j['meshes']),'bytes':len(b),'materials':len(j['materials']),'runtime_optimization':proof});(P/'verification_corrected.json').write_text(json.dumps(v,indent=2));print('RUNTIME_OPTIMIZED',json.dumps(proof))

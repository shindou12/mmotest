import bpy,pathlib,json
R=pathlib.Path(__file__).resolve().parent
for k in range(1,8):
 p=R/f'M{k:02d}';bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(p/'cart_corrected.glb'))
 textured=[];missing=[];quiet=[]
 for o in [x for x in bpy.context.scene.objects if x.type=='MESH']:
  uses_texture=any(any(n.type=='TEX_IMAGE' and n.image for n in m.node_tree.nodes) for m in o.data.materials if m)
  if uses_texture:
   textured.append(o.name)
   if not o.data.uv_layers:missing.append(o.name)
  elif not o.data.uv_layers:quiet.append(o.name)
 v=json.loads((p/'glb_reimport_verification.json').read_text());v.update({'textured_mesh_objects':len(textured),'textured_mesh_without_uv':missing,'constant_color_meshes_without_uv':len(quiet)});(p/'glb_reimport_verification.json').write_text(json.dumps(v,indent=2));print('TEXTURE_UV_AUDIT',k,len(textured),missing,len(quiet))

from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageStat
from pathlib import Path
import json
R=Path(r'C:/Users/shind/Documents/ChatGPT/temp/output/asset_method_lab/cart');font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20);small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
def cell(im,xy,path,label,size=(420,350)):
 d=ImageDraw.Draw(im);im.paste(Image.open(path).convert('RGB').resize(size),xy);d.text((xy[0]+12,xy[1]+9),label,font=font,fill=(237,224,196))
fronts=Image.new('RGB',(1260,1170),(36,44,45))
for i in range(7):
 p=R/f'M{i+1:02d}';cell(fronts,((i%3)*420,(i//3)*390),p/'corrected_front.png',f'M{i+1:02d}'+(' | selected' if i==5 else ' | bake rejected' if i==3 else ''))
 d=ImageDraw.Draw(fronts);d.text(((i%3)*420+12,(i//3)*390+356),['Reference / color bake','Silhouette extrusion','Mortise-and-tenon assembly','High-to-low tangent bake','Directional trim UV','Curve-designed stock','Dimensioned Geometry Nodes'][i],font=small,fill=(223,208,178))
fronts.save(R/'contact_sheet.png')
for i in range(7):
 p=R/f'M{i+1:02d}';out=Image.new('RGB',(1260,780),(36,44,45))
 for j,(n,label) in enumerate([('initial_front.png','Initial'),('corrected_front.png','Corrected'),('glb_reimport_front.png','GLB reimport'),('corrected_back.png','Back'),('corrected_side.png','Side'),('corrected_end.png','End')]):cell(out,((j%3)*420,(j//3)*390),p/n,label)
 thumb=Image.open(p/'thumbnail_silhouette.png').convert('RGBA');bg=Image.new('RGBA',thumb.size,(232,223,199,255));bg.alpha_composite(thumb);bg.convert('RGB').save(p/'thumbnail_silhouette_light.png')
 out.paste(bg.convert('RGB').resize((105,87)),(1145,680));out.save(p/'review_sheet.png')
 a=Image.open(p/'corrected_front.png').convert('RGB');b=Image.open(p/'glb_reimport_front.png').convert('RGB');mean=ImageStat.Stat(ImageChops.difference(a,b)).mean
 v=json.loads((p/'glb_reimport_verification.json').read_text());v['source_to_glb_render_rgb_mean_abs_difference_255']=mean;(p/'glb_reimport_verification.json').write_text(json.dumps(v,indent=2))

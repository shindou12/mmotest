# Cart method lane

Seven empty-scene workflows were executed. Selected: M06 curve-designed aged stock. M04 is retained and rejected because its real normal bake produces visible artifacts. The other methods are readable baselines. All seven delivered model-only BLEND/GLB files, textures, initial/corrected renders, critique and reimport verification.

## M01 — Generated reference -> measured blocking -> painted diffuse bake

Initial atlas existed but the delivery shader used a remaining unrelated UV layer: nearly black whole cart with striped rim. Tall wall also hid the load bed.

Removed non-atlas UVs, made the baked atlas active for rendering, lowered wall .70 -> .57m. Final front/back/side/end show broad bed and intact wheels.

Status: baseline. Reference sheet has perspective inconsistency. Wood is a restrained generic baseline; atlas loses independent metal response.

## M02 — 2D profile outlines -> extrusion -> transverse-depth correction

Initial elevation read well but the shallow cargo bed and thin wheel felloes made the cart look narrow and sheet-like.

Expanded transverse bed width and wheel spacing, thickened felloe depth .09 -> .16m. Profile outlines preserved.

Status: baseline. Best for fast drawn silhouettes. Clean repeated rows remain less expressive than selected aged stock.

## M03 — Structural mortise/tenon modules -> load bed -> surface

Outside diagonal dominated the broad side mass and cut across the wheel. Tall corner stakes made the bed feel fenced in.

Moved braces under the floor to the chassis and shortened corner posts .98 -> .82m. Kept actual mortise cuts and load path.

Status: baseline. Joinery detail mostly secondary at thumbnail. Ordered parts still look clean and regular.

## M04 — High-resolution bevel roll -> tangent normal bake to low cage

Initial normal bake produced dark bands, rim artifacts and broken-looking small gaps. These are visible in actual renders, not merely a map diagnostic.

Reduced high bevel .06 -> .018m and strength 1.0 -> .6; rebuilt a unique UV atlas to remove mixed UV binding. Improvement was insufficient.

Status: rejected. Rejected aesthetically: crossing cage rays/normal discontinuities remain around closely packed boards and rim. Requires separated component cages or a different normal strategy.

## M05 — Directional painted trim -> reused UV stock -> assembly

Initial sidewall UVs visibly ran grain across the boards and repeated the same light/dark stripe on all rows.

Aligned sidewall grain along each board long axis and distributed three palette bands.

Status: baseline. Extremely compact texture reuse but repetition remains in the uniform geometry. Good supporting workflow, not strongest finished silhouette.

## M06 — Bezier-designed warped stock -> flared assembly -> broad pigment pass

Initial .095m curve amplitude looked rubbery. First reduced-wave pass remained a generic regular box, confirmed by parent review.

Reduced warp to .022m; varied large plank heights; flared load mass and stakes; selected asymmetrical edge losses; broad paint islands; tangential felloe grain and tapered spokes. Corrected hanging shaft collars after side/rear inspection.

Status: selected. Selected as strongest painterly result. No engineered suspension or horse. Curve guides are recorded in verification JSON/replay source; delivery blend contains editable realized meshes.

## M07 — Geometry Nodes dimensioned body -> semantic attributes -> per-stock UV

Initial 12 spokes crowded the wheel and global body UV projection sent grain across end walls.

Reduced to eight spokes and mapped each connected stock island by its own longest dimension; source keeps live node modifier.

Status: baseline. Actual editable parametric BODY, not a fully parametric entire cart. Python builds wheel/shaft/chassis placement; changing body length alone does not move the endwall stations.

## Verification

All corrected GLBs were imported into empty scenes and rendered with the same rig. Every textured mesh has UVs, textures are embedded/loaded, bounds are finite and length is 5.0 units. No camera or light is exported. Source-versus-reimport RGB mean absolute difference is below 0.009 on a 0–255 scale for every method. This measures file fidelity, not artistic quality.

M07 source has 66 links, live dimension inputs and component IDs 1–5. A Bed Length change to 3.02 changes evaluated body length from 2.345 to 3.02; audit records the actual geometry response. The entire cart is not fully linked to those controls.

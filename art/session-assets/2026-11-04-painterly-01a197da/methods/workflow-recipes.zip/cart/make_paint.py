from PIL import Image,ImageDraw,ImageFilter
import random, math, pathlib, json
root=pathlib.Path(__file__).resolve().parent
root.mkdir(parents=True,exist_ok=True)
random.seed(47)
W,H=1024,1024
im=Image.new('RGB',(W,H));d=ImageDraw.Draw(im)
pal=[(155,100,49),(177,119,57),(194,140,73),(146,91,43)]
for band in range(4):
 y0=band*256; base=pal[band];d.rectangle((0,y0,1024,y0+256),fill=base)
 # broad long pigment islands with tapered ends, never all-edge outline
 for i in range(70):
  x=random.randint(-180,1024); y=y0+random.randint(14,242); ln=random.randint(70,390); th=random.randint(3,16); delta=random.choice([-15,-9,8,13,18]); c=tuple(max(0,min(255,v+delta)) for v in base)
  d.polygon([(x,y),(x+ln*.2,y-th*.5),(x+ln*.7,y-th*.3),(x+ln,y),(x+ln*.83,y+th*.45),(x+ln*.28,y+th*.3)],fill=c)
 for i in range(9):
  x=random.randint(-100,1000); y=y0+random.randint(15,245);ln=random.randint(90,270)
  pts=[(x+j*ln/14,y+math.sin(j*.5+i)*2.4) for j in range(15)];d.line(pts,fill=tuple(v-24 for v in base),width=2)
 # a small knot, offset so not every plank centre
 cx=700 if band%2==0 else 240;cy=y0+140
 for a,b in [(45,12),(27,8),(12,4)]:
  d.ellipse((cx-a,cy-b,cx+a,cy+b),outline=tuple(v-26 for v in base),width=2)
 d.line([(0,y0+4),(1024,y0+4)],fill=tuple(v+25 for v in base),width=6)
im.save(root/'wood_trim.png')
# duplicate resources into each method for portable sources
for k in range(1,8):
 p=root/f'M{k:02d}';p.mkdir(exist_ok=True);im.save(p/'wood_trim.png')
(root/'reference_measurements.json').write_text(json.dumps({'source':'M01/reference_3view.png','pixel_measurements':{'side_wheel_diameter':287,'side_bed_length':565,'side_wall_height':200,'side_shaft_extension':410,'front_outer_width':438},'ratios_wheel_diameter_1':{'bed_length':1.97,'wall_height':.70,'shaft_extension':1.43,'outer_width':1.53},'interpretation':'Generated sheet uses perspective despite orthographic request; use ratios as design guides, not exact engineering projections.'},indent=2))

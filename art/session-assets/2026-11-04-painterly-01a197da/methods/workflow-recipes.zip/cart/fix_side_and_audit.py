import bpy,pathlib,sys,shutil,json
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(R));import review_rig
for k in [1,2,3,4,5,7]:
 p=R/f'M{k:02d}';bpy.ops.wm.open_mainfile(filepath=str(p/'cart_corrected.blend'))
 old=p/'corrected_side.png';shutil.copy2(old,p/'side_camera_clip_archive.png')
 cam=review_rig.setup((720,600),6.35,(0,0,1.03));bpy.context.scene.cycles.samples=12
 review_rig.shot(cam,old,(0,-14,3.37),(0,0,1.03))
bpy.ops.wm.open_mainfile(filepath=str(R/'M07/source_corrected.blend'))
o=next(o for o in bpy.context.scene.objects if o.modifiers and o.modifiers[0].type=='NODES');m=o.modifiers[0];g=m.node_group
iface=[{'name':s.name,'identifier':s.identifier,'type':s.socket_type} for s in g.interface.items_tree if s.item_type=='SOCKET']
def dims():
 bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());v=[ev.matrix_world@Vector(q) for q in ev.bound_box];return [max(q[i] for q in v)-min(q[i] for q in v) for i in range(3)]
base=dims();sock=next(s for s in g.interface.items_tree if s.name=='Bed Length');getattr(m.properties.inputs,sock.identifier).value=3.02;g.update_tag();o.update_tag();changed=dims()
# Attribute values on evaluated GN mesh prove material/semantic distribution.
ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();at=me.attributes.get('component_id');vals=sorted(set(a.value for a in at.data)) if at else [];ev.to_mesh_clear()
report={'node_tree':g.name,'node_types':[n.bl_idname for n in g.nodes],'links':len(g.links),'interface':iface,'dimensions_default':base,'bed_length_test_value':3.02,'dimensions_after_length_change':changed,'component_id_values':vals,'limitation':'Body stock dimension controls are live; wheel/shaft/chassis spacing is constructed in Python, not fully linked into this node tree.'}
(R/'M07/geometry_nodes_audit.json').write_text(json.dumps(report,indent=2));print('GN_AUDIT',json.dumps(report))

import bpy,pathlib,json,math,sys
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R));import review_rig
for k in ([int(sys.argv[-1])] if len(sys.argv)>1 and sys.argv[-1].isdigit() else range(1,8)):
 p=R/f'M{k:02d}';bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 bpy.ops.import_scene.gltf(filepath=str(p/'cart_corrected.glb'))
 assets=[o for o in bpy.context.scene.objects if o.type=='MESH'];unexpected=[o.name for o in bpy.context.scene.objects if o.type in ('LIGHT','CAMERA')]
 coords=[o.matrix_world@v.co for o in assets for v in o.data.vertices];mn=[min(v[i] for v in coords) for i in range(3)];mx=[max(v[i] for v in coords) for i in range(3)]
 mats={m for o in assets for m in o.data.materials if m};texs={n.image for m in mats for n in m.node_tree.nodes if n.type=='TEX_IMAGE' and n.image}
 report={'method':f'M{k:02d}','reimported':True,'mesh_objects':len(assets),'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in assets),'uv_meshes':sum(bool(o.data.uv_layers) for o in assets),'materials':len(mats),'images':[{'name':im.name,'size':list(im.size),'packed':bool(im.packed_file),'has_data':im.has_data} for im in texs],'unexpected_camera_or_light':unexpected,'bounds':[mn,mx],'all_finite':all(math.isfinite(x) for co in coords for x in co),'normalized_length':mx[0]-mn[0]}
 cam=review_rig.setup((720,600),6.35,(0,0,1.03));bpy.context.scene.cycles.samples=12;review_rig.shot(cam,p/'glb_reimport_front.png',(-4.5,-6.6,3.5),(0,0,1.03))

 if k==6:review_rig.shot(cam,p/'glb_reimport_back.png',(4.5,6.6,3.5),(0,0,1.03))
 # Silhouette proof uses same camera/scale and imported asset; thumbnail black on transparent.
 for o in list(bpy.context.scene.objects):
  if o not in assets and o.type=='MESH':bpy.data.objects.remove(o,do_unlink=True)
 black=bpy.data.materials.new('silhouette only');black.use_nodes=True;nt=black.node_tree;nt.nodes.clear();em=nt.nodes.new('ShaderNodeEmission');em.inputs[0].default_value=(0,0,0,1);out=nt.nodes.new('ShaderNodeOutputMaterial');nt.links.new(em.outputs[0],out.inputs[0])
 for o in assets:
  o.data.materials.clear();o.data.materials.append(black)
  for poly in o.data.polygons:poly.material_index=0
 bpy.context.scene.render.film_transparent=True;bpy.context.scene.render.resolution_x=180;bpy.context.scene.render.resolution_y=150;bpy.context.scene.cycles.samples=4
 review_rig.shot(cam,p/'thumbnail_silhouette.png',(-4.5,-6.6,3.5),(0,0,1.03))
 (p/'glb_reimport_verification.json').write_text(json.dumps(report,indent=2));print('REIMPORT_VERIFIED',report['method'],report['triangles'],report['normalized_length'])

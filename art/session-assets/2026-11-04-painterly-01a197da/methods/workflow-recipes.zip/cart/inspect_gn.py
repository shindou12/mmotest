import bpy,pathlib
r=pathlib.Path(r'C:/Users/shind/Documents/ChatGPT/temp/output/asset_method_lab/cart');bpy.ops.wm.open_mainfile(filepath=str(r/'M07/source_corrected.blend'))
o=next(o for o in bpy.context.scene.objects if o.modifiers and o.modifiers[0].type=='NODES');m=o.modifiers[0]
q=getattr(m.properties.inputs,'Socket_2');print('Q',repr(q),dir(q));print('RNA',[(p.identifier,p.type) for p in q.bl_rna.properties])

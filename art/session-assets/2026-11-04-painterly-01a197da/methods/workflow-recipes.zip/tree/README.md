# Broadleaf tree workflow experiment

Seven new runs, M08-M14, use distinct crown construction algorithms. Shared trunk geometry helpers, palette, camera, lighting and top height are controlled comparison conditions. No previous tree model is imported. See `registry.json` and each method's `evidence.json` / `CRITIQUE.md` for observed failures and actual corrections, rather than invented numeric rankings.

Relative winner: `M13/tree.glb` (optimized runtime) and `M13/tree.blend` (editable model source). Final runtime is one mesh/node, two material primitives and 16,822 triangles. Both textures are embedded; the source BLEND also packs them. Its 322 foliage source meshes use real transferred loop normals. Temporary large crown sources are removed.

M13's leaf pigment/vein atlas is directly baked into its eight palette tiles. Geometry UVs choose the tile; the export does not depend on unsupported shader arithmetic. Texture files are `M13/leaf_pigment.png` and `M13/bark_paint.png`. Foliage uses actual curved broadleaf geometry with no alpha cards.

One-stop replay, sequential Blender processes only:

```powershell
powershell -ExecutionPolicy Bypass -File .\replay_all.ps1
```

Winner only, including original image, final model/renders, reimport audit, real alpha silhouettes, contacts and registry refresh:

```powershell
powershell -ExecutionPolicy Bypass -File .\replay_all.ps1 -Methods 13
```

Blender and Python paths may be overridden via `-Blender` and `-Python`. Python needs Pillow for the evidence sheets. Each method folder also contains a self-contained `source.py`, `initial_source.py` and local `review_rig.py`:

```powershell
blender --background --factory-startup --python .\M13\source.py
```

The model-only source is saved before the review floor, lights or camera are created. The source retains editable objects; a temporary duplicate is joined and its material slots collapsed for runtime export. `audit.py` imports the actual GLB, checks model-only contents, dimensions, attributes, UVs and embedded images, and renders M08/M10/M11/M13 under the same rig. `audit_silhouettes.py` preserves actual alpha cutouts, unlike a material override.

Evidence images: `initial_contact.png`, `before_after_contact.png`, `all_views_contact.png`, `thumbnail_contact.png`. Earlier M08-M10 and M13 correction stages remain in their folders. The rejected M10-M12 workflows are still technically valid exports; they are not artistic winners.

Limits of the winner: stronger macro asymmetry and larger sky windows would improve it. The bark is warmer and broader after correction, but less richly painted than the stump reference. This is a relative best pipeline for parent integration, not a claim that all seven trials are publication quality.

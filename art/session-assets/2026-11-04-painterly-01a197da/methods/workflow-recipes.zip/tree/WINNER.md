# Relative tree winner: M13

The final M13 uses actual source-surface normal transfer on foliage distributed over full 3D crown surfaces. This was selected after front, side, back and thumbnail inspection. The temporary source crowns are removed; custom normals remain on the leaf meshes and in the GLB. This avoids retaining ball-shaped crown cores.

Limits: many leaf marks are still similarly sized; the macro silhouette can be more asymmetric and the sky gaps larger. Bark is warmer after correction but less richly painted than the stump reference. This is a relative workflow winner, not a declaration that every trial is ready to publish.

M10 demonstrates real volume but its exposed field core still looks like a faceted lump. M11 exposes card repetition. M12 retains boulder hulls. Their failure images are intentionally kept.

Files: M13/tree.blend, M13/tree.glb, M13/bark_paint.png; all-view and before/after sheets in this directory. Per-method sources are self-contained with local review_rig.py. All seven GLBs were imported and checked; M08/M10/M11/M13 also have matching same-rig reimport render comparisons.

Final export: one node, one mesh, two material primitives, 16,822 triangles. Two embedded images: bark_paint.png and leaf_pigment.png. The latter is an eight-color pigment/vein atlas on real leaf geometry, not alpha cards. Source tree.blend retains 335 editable model objects and packed images. The export joins only temporary duplicates; real transferred split normals survive and same-rig reimport render difference is below 0.03 RGB mean error on the 0-255 scale.

from PIL import Image
from pathlib import Path
R=Path(__file__).resolve().parent
leaf=Image.open(R.parent/'M13/leaf_pigment.png').convert('RGB')
bark=Image.open(R.parent/'M13/bark_paint.png').convert('RGB')
im=Image.new('RGB',(2048,1024))
for i in range(8):
 im.paste(leaf.crop((i*256,0,(i+1)*256,256)).resize((256,512)),(i*256,0))
for i in range(4):im.paste(bark.resize((512,512)),(i*512,512))
im.save(R/'atlas_guide.png')

# UV atlas repaint

Built-in image_gen edit. Frozen generated PNG is the replay input; generation itself is not deterministic.

Edit target: atlas_guide.png. Style reference: output/stump_painterly_v1/exported_front_v3.png. Exact prompt:

Edit target: image 1, a UV texture atlas. Supporting style reference only: image 2, painterly stump. Repaint ONLY the atlas, preserve EXACT 2:1 rectangular layout and tile boundaries: top half has EIGHT equal narrow vertical leaf texture swatches, bottom half has FOUR equal wide square bark swatches. No borders, no labels, no objects or perspective. Top row: each tile is a FULL BLEED olive/yellow-green painted leaf surface (NOT isolated leaves), leaf axis horizontal left-to-right, quiet broad brush dabs, a restrained horizontal central vein with a few angled veins. Palette proceeds dark olive left toward golden green middle-right then dark olive last two; moderate value contrast, no white or neon. Bottom row: four subtly different golden brown bark textures filling the tiles, vertical flowing grain, wide uneven paint planes, sparse dark fissures and tiny knots. Match the broad intentional paint facets of the stump, avoid micro noise, photographs, rendered lighting, glossy plastic or deep baked shadows. Keep all pixel space filled with pigment; no blank space or transparency. This will map directly onto real UVs.

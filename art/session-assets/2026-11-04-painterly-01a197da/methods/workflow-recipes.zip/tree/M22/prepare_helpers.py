"""Snapshot disclosed M13 primitive/normal-transfer helpers, never its mesh."""
from pathlib import Path
R=Path(__file__).resolve().parent
s=(R.parent/'M13/source.py').read_text()
s=s.split("globals()['m'+str(METHOD).zfill(2)]()")[0]
s=s.replace("args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['13','fix']; METHOD=int(args[0]); FIX=len(args)>1 and args[1]=='fix'",'METHOD=13; FIX=True')
s=s.replace('random.Random(1313+ii)','random.Random(2217+ii)')
s=s.replace('rng.choice([.25,.31,.38]) if z>.3 else rng.choice([.18,.21,.25])','rng.choice([.27,.37,.48]) if z>.3 else rng.choice([.13,.22,.28])')
(R/'geometry_helpers.py').write_text(s)
print('HELPER_SNAPSHOT_READY')

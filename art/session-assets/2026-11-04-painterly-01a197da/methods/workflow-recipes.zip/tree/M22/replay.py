"""Fresh parametric geometry -> UV image repaint -> actual color bake -> runtime GLB.
Run with Blender --python replay.py -- initial|painted|corrected.
Frozen generated atlas is an explicit replay input, generation is not deterministic.
"""
from pathlib import Path
import sys,json,struct
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import geometry_helpers as h
import bpy
from mathutils import Vector
stage=sys.argv[-1] if sys.argv[-1] in ['initial','painted','corrected'] else 'initial'
h.CENTERS=[((-1.0,-.05,3.05),(1,.74,.64)),((-.75,.08,3.65),(.93,.78,.68)),((.1,.3,4),(1.18,.82,.72)),((1.15,.25,3.45),(.65,.60,.52)),((.66,-.55,3.1),(.61,.50,.42)),((-1.7,.2,2.75),(.43,.43,.34)),((.15,.85,3.38),(.83,.68,.50))]
if stage=='corrected':
 # Painted test retained an almost continuous oval dome; open a low right notch,
 # lower the left secondary bough, and let one high lobe dominate.
 h.CENTERS=[((-.98,-.05,3.12),(.85,.70,.55)),((-.85,.12,3.70),(.82,.72,.58)),((.1,.30,4.12),(1.10,.80,.72)),((1.43,.28,3.47),(.62,.57,.43)),((.88,-.55,2.95),(.48,.43,.32)),((-1.65,.16,2.82),(.52,.43,.32)),((.15,.92,3.45),(.73,.63,.45))]
h.m13()
objects=h.ASSET
pts=[o.matrix_world@v.co for o in objects for v in o.data.vertices];factor=4.6/max(v.z for v in pts)
for o in objects:o.scale*=factor;o.location*=factor
atlas=bpy.data.images.load(str(R/('atlas_guide.png' if stage=='initial' else 'atlas_generated.png')));atlas.pack()
m=h.material('M22 | actual repainted UV atlas','FFFFFF');nt=m.node_tree;bs=nt.nodes.get('Principled BSDF');tx=nt.nodes.new('ShaderNodeTexImage');tx.image=atlas
uv=nt.nodes.new('ShaderNodeUVMap');uv.uv_map='paint_uv';nt.links.new(uv.outputs[0],tx.inputs['Vector'])
nt.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
for o in objects:
 leaf=any(slot.material in h.LEAF for slot in o.material_slots)
 layer=o.data.uv_layers.active
 if not layer:layer=o.data.uv_layers.new()
 layer.name='paint_uv'
 for v in layer.data:
  u,w=v.uv
  if leaf:v.uv=(u,.51+w*.48)
  else:
   # Four full bark panels, preserving the longitudinal axis of each tube.
   panel=sum(ord(c) for c in o.name)%4;v.uv=((panel+.02+(u%1)*.96)/4,.01+min(1,max(0,w))*.48)
 o.data.materials.clear();o.data.materials.append(m)
 for p in o.data.polygons:p.material_index=0
for im in bpy.data.images:
 if im.source=='FILE':im.pack()
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.wm.save_as_mainfile(filepath=str(R/f'tree_{stage}.blend'))
# Join temporary runtime copies; editable source stays separate on disk.
bpy.ops.object.duplicate();bpy.ops.object.join();o=bpy.context.object;o.name='Painted_Broadleaf_Runtime'
o.data.uv_layers.new(name='runtime_atlas');o.data.uv_layers.active=o.data.uv_layers['runtime_atlas'];o.data.uv_layers.active.active_render=True
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.008);bpy.ops.object.mode_set(mode='OBJECT')
image=bpy.data.images.new('M22 baked repainted atlas '+stage,width=2048,height=2048,alpha=False)
node=nt.nodes.new('ShaderNodeTexImage');node.image=image;nt.nodes.active=node
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=1
scene=bpy.context.scene;scene.render.bake.use_selected_to_active=False;scene.render.bake.use_pass_direct=False;scene.render.bake.use_pass_indirect=False;scene.render.bake.use_pass_color=True;scene.render.bake.margin=8
bpy.ops.object.bake(type='DIFFUSE');image.filepath_raw=str(R/f'baked_color_{stage}.png');image.file_format='PNG';image.save();image.pack()
runtime=h.material('M22 | baked color','FFFFFF');tex=runtime.node_tree.nodes.new('ShaderNodeTexImage');tex.image=image;runtime.node_tree.links.new(tex.outputs[0],runtime.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
o.data.materials.clear();o.data.materials.append(runtime)
for p in o.data.polygons:p.material_index=0
for layer in list(o.data.uv_layers):
 if layer.name!='runtime_atlas':o.data.uv_layers.remove(layer)
for obj in list(bpy.context.scene.objects):
 if obj!=o:bpy.data.objects.remove(obj,do_unlink=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/f'tree_runtime_{stage}.blend'))
bpy.ops.export_scene.gltf(filepath=str(R/f'tree_{stage}.glb'),export_format='GLB',use_selection=True,export_apply=True,export_normals=True,export_cameras=False,export_lights=False)
cam=h.rig.setup((800,800),6.05,(0,0,2.35));scene.cycles.samples=16
for name,loc in {'front':(6,-10,6),'back':(-6,10,6),'side':(10,1,5.5)}.items():h.rig.shot(cam,R/f'{stage}_{name}.png',loc,(0,0,2.35))
(R/f'build_{stage}.json').write_text(json.dumps({'method':'M22','stage':stage,'fresh_geometry':True,'shared_helpers':'M13 primitive/normal-transfer source snapshot, no mesh import','runtime_meshes':1,'materials':1,'editable_objects':len(objects),'triangles':sum(len(p.vertices)-2 for p in o.data.polygons),'bake':'DIFFUSE color only; no direct or indirect light','source_atlas':atlas.filepath,'custom_normals':o.data.has_custom_normals},indent=2))
print('M22_BUILD_READY',stage)


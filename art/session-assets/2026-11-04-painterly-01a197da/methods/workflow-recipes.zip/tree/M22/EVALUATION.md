# M22 — generated paint on the actual UV atlas

Geometry starts from empty scene, using the disclosed M13 primitive and DataTransfer helpers with different crown centers, sizes, seeds and leaf scales. No prior tree mesh is imported. atlas_guide.png contains the exact eight-leaf/four-bark sampling layout. image_gen edited it with the older stump as a style reference; the exact prompt and frozen generated PNG are retained.

The actual generated image is sampled through the leaf and trunk UVs, then a real DIFFUSE color-only bake produces a unique runtime atlas. Initial geometry/pigment, generated paint, and corrected crown images are retained. The painted version retained an oval continuous crown. Moving/reducing the low right group and lowering the left group opens a more readable gap. A UV endpoint wrap was corrected before the painted pass.

Front/back/side show that painted leaf veins and warm bark alone cannot solve the canopy's repeated leaf shapes or pointed buttress roots. The corrected geometry is a useful variant, but M13 remains the relative primary tree winner. Generated atlas painting is a useful downstream operation, not a substitute for mass design. The final one-mesh/one-material GLB is genuinely reimported; matching images are independently compared.

param(
 [string]$Blender = 'C:/Program Files/Blender Foundation/Blender 5.2/blender.exe',
 [string]$Python = 'C:/Users/shind/AppData/Local/Programs/Python/Python313/python.exe',
 [int[]]$Methods = @(8,9,10,11,12,13,14)
)
$ErrorActionPreference = 'Stop'
foreach ($method in $Methods) {
 $folder = Join-Path $PSScriptRoot ('M{0:00}' -f $method)
 & $Blender --background --factory-startup --python (Join-Path $folder 'initial_source.py')
 if ($LASTEXITCODE -ne 0) { throw ('Initial method failed: ' + $method) }
 & $Blender --background --factory-startup --python (Join-Path $folder 'source.py')
 if ($LASTEXITCODE -ne 0) { throw ('Corrected method failed: ' + $method) }
}
& $Blender --background --factory-startup --python (Join-Path $PSScriptRoot 'audit.py') -- @Methods
if ($LASTEXITCODE -ne 0) { throw 'Export audit failed' }
& $Blender --background --factory-startup --python (Join-Path $PSScriptRoot 'audit_silhouettes.py') -- @Methods
if ($LASTEXITCODE -ne 0) { throw 'Silhouette render failed' }
& $Python (Join-Path $PSScriptRoot 'make_contacts.py')
& $Python (Join-Path $PSScriptRoot 'write_ledger.py')

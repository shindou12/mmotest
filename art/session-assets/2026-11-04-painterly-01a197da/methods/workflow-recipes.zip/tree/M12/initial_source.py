import bpy, bmesh, math, random, sys, json, os
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
import importlib.util
spec=importlib.util.spec_from_file_location('rig',str(ROOT/'review_rig.py')); rig=importlib.util.module_from_spec(spec);spec.loader.exec_module(rig)
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['12']; METHOD=int(args[0]); FIX=len(args)>1 and args[1]=='fix'
OUT=ROOT; OUT.mkdir(exist_ok=True)
random.seed(METHOD*123+6)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
ASSET=[]; MATS=[]
def material(name,h):
 m=bpy.data.materials.new(name);m.diffuse_color=rig.rgb(h);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rig.rgb(h);p.inputs['Roughness'].default_value=.88;return m
LEAF=[material('Foliage paint '+str(i),h) for i,h in enumerate(['69753B','778744','8A984B','A2AD55','B4B960','C0C66C','536239','66713D'])]
BARK=[material('Bark paint '+str(i),h) for i,h in enumerate(['7C512F','936238','AA7945','BF9055','805C3D','68462E'])]
def mesh(name,vs,fs,mats,assign=None):
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);ASSET.append(o)
 for m in mats:me.materials.append(m)
 for p in me.polygons:
  if assign:p.material_index=assign(p)
 return o
def tube(name,pts,rs):
 vs=[];fs=[];n=9
 for i,p in enumerate(pts):
  tangent=Vector(pts[min(i+1,len(pts)-1)])-Vector(pts[max(0,i-1)]);tangent.normalize();u=tangent.cross(Vector((0,1,0))).normalized();v=tangent.cross(u).normalized()
  for j in range(n):
   a=j*2*math.pi/n; q=Vector(p)+rs[i]*(u*math.cos(a)+v*math.sin(a))*(1+.06*math.sin(j*11+i));vs.append(q)
 for i in range(len(pts)-1):
  for j in range(n):fs.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 fs.append(tuple(range(n-1,-1,-1)));fs.append(tuple((len(pts)-1)*n+j for j in range(n)))
 return mesh(name,vs,fs,BARK,lambda p:[1,2,3,2,0,4,1,5,0][p.index%n])
def trunk():
 tube('Curved trunk',[(0,0,0),(.03,.02,.4),(-.16,.05,1.1),(-.1,.03,1.7),(.14,.1,2.3),(.25,.12,2.95),(.15,.12,3.65)],[.32,.28,.23,.19,.15,.10,.025])
 for a,ln in [(0,1),(1.25,.7),(2.5,.95),(3.7,.65),(5,1.0)]:
  tube('Buttress root',[(0,0,.45),(.35*math.cos(a),.35*math.sin(a),.14),(ln*math.cos(a),ln*math.sin(a),.025)],[.16,.13,.025])
CENTERS=[((-1.02,-.06,3.04),(1.02,.72,.57)),((-.8,.1,3.74),(.99,.73,.61)),((.22,.16,4.11),(1.04,.79,.63)),((1.12,.18,3.65),(.81,.64,.52)),((.7,-.48,3.15),(.72,.53,.43)),((-1.62,.1,2.73),(.58,.48,.35)),((-.12,.75,3.42),(.78,.63,.47))]
if not FIX:CENTERS=[(c,(s[0]*.82,s[1],s[2]*1.25)) for c,s in CENTERS]
def branches():
 for i,(c,s) in enumerate(CENTERS):
  tube('Crown support '+str(i),[(-.1,.04,1.5+i*.13),(c[0]*.45,c[1]*.6,2.45+i*.06),(c[0],c[1],c[2]-.15)],[.12-i*.009,.075,.018])
def plate(name,c,s,seed=0,norm=None,card=False):
 # A scalloped flattened broad-leaf group, deliberately distinct from a sphere.
 rng=random.Random(seed);c=Vector(c);n=10;vs=[tuple(c+Vector((0,0,.10*s[2])))];fs=[]
 for j in range(n):
  a=j*2*math.pi/n;r=1+rng.uniform(-.18,.18);vs.append(tuple(c+Vector((math.cos(a)*s[0]*r,math.sin(a)*s[1]*r,math.sin(a*3)*.06*s[2]))))
 vs.append(tuple(c+Vector((0,0,-s[2]*.23))))
 for j in range(n):fs.extend([(0,1+j,1+(j+1)%n),(n+1,1+(j+1)%n,1+j)])
 o=mesh(name,vs,fs,LEAF,lambda p:min(7,max(0,3+int(c.z*.32)+rng.choice([-2,-1,0,0,1])-2*(p.index%2))))
 return o
def crown_shell(c,s,seed=0):
 rng=random.Random(seed);vs=[];fs=[];N=14
 for k,(r,z) in enumerate([(.2,-.7),(.88,-.35),(1,.07),(.73,.63),(.23,.9)]):
  for j in range(N):
   a=2*math.pi*j/N; rr=r*(1+rng.uniform(-.14,.14));vs.append((c[0]+math.cos(a)*s[0]*rr,c[1]+math.sin(a)*s[1]*rr,c[2]+s[2]*(z+rng.uniform(-.12,.12))))
 for k in range(4):
  for j in range(N):fs.append((k*N+j,k*N+(j+1)%N,(k+1)*N+(j+1)%N,(k+1)*N+j))
 fs += [tuple(range(N-1,-1,-1)),tuple(4*N+j for j in range(N))]
 o=mesh('Hierarchical scalloped crown',vs,fs,LEAF,lambda p:min(6,max(0,int(3+p.normal.z*2)+rng.choice([-1,0,0,1]))));return o
def patches(c,s,num,seed):
 rng=random.Random(seed)
 for i in range(num):
  a=rng.uniform(0,math.tau);r=math.sqrt(rng.random()); z=rng.uniform(-.2,.65)
  p=(c[0]+math.cos(a)*s[0]*r,c[1]+math.sin(a)*s[1]*r,c[2]+s[2]*z)
  sz=rng.uniform(.15,.3);plate('Broadleaf paint group',p,(sz*1.5,sz,.3),seed*100+i)
def m08():
 trunk();branches()
 for i,(c,s) in enumerate(CENTERS):
  crown_shell(c,s,i+9);patches(c,s,19 if FIX else 7,80+i)
def m09():
 trunk()
 # Skeleton first. Bezier curves are converted only after tapering by point radius.
 for i,(c,s) in enumerate(CENTERS):
  cu=bpy.data.curves.new('Tapered spline architecture','CURVE');cu.dimensions='3D';cu.resolution_u=5;cu.bevel_depth=.13;cu.bevel_resolution=1
  sp=cu.splines.new('BEZIER');sp.bezier_points.add(3)
  for k,p in enumerate([(-.1,0,1.4+i*.14),(c[0]*.35,c[1]*.3,2.4),(c[0]*.78,c[1],c[2]-.18),c]):
   bp=sp.bezier_points[k];bp.co=p;bp.handle_left_type='AUTO';bp.handle_right_type='AUTO';bp.radius=[1,.75,.4,.06][k]
  o=bpy.data.objects.new('Editable tapered branch',cu);bpy.context.collection.objects.link(o);cu.materials.append(BARK[2]);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');ASSET.append(bpy.context.object);o.select_set(False)
  for j in range(9 if FIX else 5):
   a=j*2.399; r=math.sqrt((j+.4)/9);p=(c[0]+math.cos(a)*s[0]*r,c[1]+math.sin(a)*s[1]*r,c[2]+.15*math.sin(j*2));tube('Fine supporting twig',[c,p],[.025,.008])
   for k in range(3):plate('Tip leaf fan',(p[0]+.17*math.cos(k*2.1),p[1]+.14*math.sin(k*2.1),p[2]+k*.035),(.36,.25,.3),1000+i*40+j*3+k)
def m10():
 trunk();branches()
 # Independent signed-field sculpt. Negative metaballs carve open slots before conversion.
 for i,(c,s) in enumerate(CENTERS):
  mb=bpy.data.metaballs.new('Metaball sculpt');mb.resolution=.11;mb.render_resolution=.09;mb.threshold=.64
  o=bpy.data.objects.new('Sculpted crown '+str(i),mb);bpy.context.collection.objects.link(o);o.location=c;o.scale=s
  for p,r in [((-.35,0,0),.8),((.3,.05,.12),.88),((0,.35,.24),.69),((.05,-.38,-.05),.67)]:e=mb.elements.new();e.co=p;e.radius=r
  if FIX:
   e=mb.elements.new();e.co=(.7,-.2,-.2);e.radius=.55;e.use_negative=True
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');o=bpy.context.object;ASSET.append(o)
  dec=o.modifiers.new('Planar reduction','DECIMATE');dec.ratio=.16;bpy.ops.object.modifier_apply(modifier=dec.name)
  for m in LEAF:o.data.materials.append(m)
  for p in o.data.polygons:p.material_index=max(0,min(6,3+int(p.normal.z*2)+random.choice([-1,0,0,1])))
  patches(c,tuple(x*.9 for x in s),26 if FIX else 8,i+70)
def make_leaf_sheet():
 # Reproducible painted alpha atlas, generated from overlapping brush dabs, no external image.
 size=256;im=bpy.data.images.new('Painted broadleaf alpha',width=size,height=size,alpha=True);pixels=[]
 for y in range(size):
  for x in range(size):
   u=(x-128)/117;v=(y-128)/116;edge=(abs(u)**1.5+abs(v*.88)**2);alpha=1 if edge<.78+.10*math.sin(math.atan2(v,u)*9) else 0
   stroke=.035*math.sin(u*24+math.sin(v*12)*2)+.025*math.sin(v*35+u*6);vein=.10*math.exp(-abs(u-v*.12)*60)
   col=(.48+stroke+vein,.57+stroke+vein,.23+stroke*.5)
   pixels.extend((*col,alpha))
 im.pixels=pixels;im.filepath_raw=str(OUT/'leaf_sheet.png');im.file_format='PNG';im.save();return im
def m11():
 trunk();branches();im=make_leaf_sheet();mat=material('Painted alpha broadleaf','91A34B');mat.surface_render_method='DITHERED';nt=mat.node_tree;p=nt.nodes.get('Principled BSDF');tex=nt.nodes.new('ShaderNodeTexImage');tex.image=im;nt.links.new(tex.outputs['Color'],p.inputs['Base Color']);nt.links.new(tex.outputs['Alpha'],p.inputs['Alpha'])
 rng=random.Random(118)
 for ii,(c,s) in enumerate(CENTERS):
  for j in range(42 if FIX else 26):
   a=rng.random()*math.tau;r=math.sqrt(rng.random());p=Vector((c[0]+math.cos(a)*s[0]*r,c[1]+math.sin(a)*s[1]*r,c[2]+rng.uniform(-.35,.45)*s[2]));w=rng.uniform(.28,.48);h=w*rng.uniform(.68,.92)
   ang=rng.uniform(-.5,.5) if FIX else rng.uniform(-1.2,1.2);u=Vector((math.cos(a),math.sin(a),ang));v=Vector((-math.sin(a),math.cos(a),.25));o=mesh('Painted broad leaf card',[p-u*w-v*h,p+u*w-v*h,p+u*w+v*h,p-u*w+v*h],[(0,1,2,3)],[mat]);uv=o.data.uv_layers.new()
   for li,xy in zip(o.data.polygons[0].loop_indices,[(0,0),(1,0),(1,1),(0,1)]):uv.data[li].uv=xy
def m12():
 trunk();branches()
 for ii,(c,s) in enumerate(CENTERS):
  rng=random.Random(912+ii);pts=[]
  for j in range(40):
   a=rng.random()*math.tau;z=rng.uniform(-.6,.8);r=(1-z*z)**.5;pts.append((c[0]+math.cos(a)*s[0]*r*rng.uniform(.7,1.1),c[1]+math.sin(a)*s[1]*r,c[2]+s[2]*z))
  bm=bmesh.new();[bm.verts.new(p) for p in pts];bmesh.ops.convex_hull(bm,input=list(bm.verts),use_existing_faces=False);me=bpy.data.meshes.new('Point cloud convex hull');bm.to_mesh(me);bm.free();o=bpy.data.objects.new('Convex crown plane',me);bpy.context.collection.objects.link(o);ASSET.append(o)
  for m in LEAF:me.materials.append(m)
  for p in me.polygons:p.material_index=max(0,min(6,3+int(p.normal.z*2)+rng.choice([-1,0,0,1])))
  if FIX:patches(c,s,27,120+ii)
def m13():
 trunk();branches()
 for ii,(c,s) in enumerate(CENTERS):
  # True source surface and loop-normal DataTransfer, not a normal-map simulation.
  src=crown_shell(c,s,900+ii)
  for p in src.data.polygons:p.use_smooth=True
  first=len(ASSET);patches(c,s,50 if FIX else 28,130+ii)
  leaves=ASSET[first:]
  for o in leaves:
   for p in o.data.polygons:p.use_smooth=True
   mod=o.modifiers.new('Actual crown normal transfer','DATA_TRANSFER');mod.object=src;mod.use_loop_data=True;mod.data_types_loops={'CUSTOM_NORMAL'};mod.loop_mapping='POLYINTERP_NEAREST';mod.mix_factor=1 if FIX else .3;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
  bpy.data.objects.remove(src,do_unlink=True);ASSET.remove(src)
def m14():
 trunk();rng=random.Random(140)
 def grow(start,direction,length,radius,depth,index):
  end=Vector(start)+Vector(direction).normalized()*length
  mid=Vector(start).lerp(end,.5)+Vector((.04*math.sin(index),.03,.11));tube('Grammar branch L'+str(depth),[start,mid,end],[radius,radius*.67,radius*.22])
  if depth==0:
   # Explicit front-central sky gap and very low twig pruning.
   if FIX and end.y<.12 and abs(end.x)<.42:return
   for j in range(4 if FIX else 2):plate('Grammar terminal broadleaves',end+Vector((math.cos(j*2.4)*.17,math.sin(j*2.4)*.16,j*.025)),(.34 if j==0 else .24,.25,.3),index*10+j)
   return
  for k in range(3):
   a=k*math.tau/3+index*2.4;d=Vector(direction)*.45+Vector((math.cos(a)*.75,math.sin(a)*.67,.32));grow(end,d,length*.67,radius*.49,depth-1,index*3+k+1)
 for i,(c,s) in enumerate(CENTERS):grow((-.1,.05,1.8+i*.05),Vector(c)-Vector((-.1,.05,1.8+i*.05)),.95+i*.025,.09,2,i+1)
globals()['m'+str(METHOD).zfill(2)]()
# Normalize all methods to identical display height, retaining different intrinsic crown widths.
coords=[o.matrix_world@v.co for o in ASSET for v in o.data.vertices];maxz=max(v.z for v in coords);factor=4.6/maxz
for o in ASSET:o.scale*=factor;o.location*=factor
bpy.context.view_layer.update()
if FIX:
 bpy.ops.object.select_all(action='DESELECT')
 for o in ASSET:o.select_set(True)
 bpy.context.view_layer.objects.active=ASSET[0]
 bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'tree.blend'))
 bpy.ops.export_scene.gltf(filepath=str(OUT/'tree.glb'),export_format='GLB',use_selection=True,export_apply=True,export_normals=True,export_materials='EXPORT')
 # Dimensions, scene contents and exported primitive counts are separately inspected by the audit.
 stats={'method':METHOD,'objects':len(ASSET),'vertices':sum(len(o.data.vertices) for o in ASSET),'polygons':sum(len(o.data.polygons) for o in ASSET),'height':4.6,'fix':FIX,'glb_bytes':(OUT/'tree.glb').stat().st_size}
 (OUT/'build_stats.json').write_text(json.dumps(stats,indent=2))
cam=rig.setup((700,700),6.05,(0,0,2.35));bpy.context.scene.cycles.samples=16
rig.shot(cam,OUT/('corrected_front.png' if FIX else 'initial_front.png'),(6,-10,6),(0,0,2.35))
if FIX:
 rig.shot(cam,OUT/'corrected_side.png',(10,1,5.5),(0,0,2.35));rig.shot(cam,OUT/'corrected_back.png',(-6,10,6),(0,0,2.35))
 # Silhouette evidence from actual mesh, flat black material override.
 black=material('PREVIEW silhouette','111718');bpy.context.scene.view_layers[0].material_override=black
 rig.shot(cam,OUT/'silhouette.png',(6,-10,6),(0,0,2.35))

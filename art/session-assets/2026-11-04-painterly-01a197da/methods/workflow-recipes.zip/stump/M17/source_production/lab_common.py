"""Shared staging/export only. Builders author independent geometry in build_method.py."""
import bpy, math, json, sys, random, numpy as np, bmesh
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'rock_painterly_v2'))
import review_rig

def clear():
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=16

def srgb(v):
    v=np.asarray(v);return np.where(v<=.04045,v/12.92,((v+.055)/1.055)**2.4)

def image_array(name,a,path,legacy=False):
    im=bpy.data.images.new(name,width=a.shape[1],height=a.shape[0],alpha=True)
    # Blender float pixels are linear; save converts to sRGB.
    rgba=np.ones((*a.shape[:2],4),dtype=np.float32);rgba[:,:,:3]=srgb(np.clip(a,0,1)) if legacy else np.clip(a,0,1)
    im.pixels.foreach_set(rgba.ravel());im.filepath_raw=str(path);im.file_format='PNG';im.save();im.pack();return im

def make_paints(folder,seed=22,calm=True,trim=False,legacy=False):
    s=1024;y,x=np.mgrid[0:s,0:s].astype(float);u=x/s;v=y/s;rng=np.random.default_rng(seed)
    # Unequal flowing bark ridges; soft broken brush patches, sparse fissures.
    warp=u+.010*np.sin(v*11+u*19)+.004*np.sin(v*25-u*13)
    bands=np.sin(warp*math.tau*13)+.33*np.sin(warp*math.tau*27+v*3)
    broad=np.sin(warp*math.tau*5+.4)
    cells=np.floor(warp*(48 if calm else 67))+np.floor((v+.05*np.sin(warp*100))*31)*113
    brush=(np.sin(cells*12.9898)*43758.5453)%1
    brush=np.floor(brush*5)/5
    value=(.065 if calm else .11)*bands+.035*broad+(.21 if calm else .075)*(brush-.5)
    crack=np.zeros_like(u)
    for i in range(13):
        cx=(i+.42+.2*np.sin(i*7))/13 + .007*np.sin(v*9+i)+.004*np.sin(v*19+i*2)
        d=np.abs((u-cx+.5)%1-.5)
        on=np.clip((np.sin(v*(6+i%4)+i)*.5+.6)*4,0,1)
        crack+=np.exp(-(d/(.0012 if calm else .0028))**2)*on
    a=np.zeros((s,s,3));a[:]=(.51,.35,.20) if calm else (.46,.29,.15);a+=value[:,:,None]*np.array((.90,.76,.53))
    a-=np.clip(crack,0,1)[:,:,None]*np.array((.17,.12,.065))
    a+=v[:,:,None]*np.array((.055,.038,.016))
    # Little low-root olive paint; no all-over green noise.
    moss=(np.sin(u*29+v*13)+np.sin(u*61-v*9)>(1.72 if calm else 1.25))*(v<(.12 if calm else .18))*(.22 if calm else .32)
    a=a*(1-moss[:,:,None])+np.array((.31,.36,.12))*moss[:,:,None]
    if trim:
        for k in range(4): a[:,k*256:(k+1)*256]*=(.92,1.03,.97,1.08)[k]
    bark=image_array('Directional bark source',a,folder/'bark_source.png',legacy=legacy)
    xx=(x/s-.5)*2;yy=(y/s-.5)*2;theta=np.arctan2(yy,xx)
    rad=np.sqrt((xx+.06)**2+(yy-.03)**2)
    wave=rad+.012*np.sin(theta*5+rad*11)+.007*np.sin(theta*9-rad*8)
    ring=(np.sin(wave*math.tau*7.1)+1)/2
    line=np.exp(-((ring-.025)/.09)**2)
    broad=np.sin(wave*math.tau*3)*.02
    a=np.zeros((s,s,3));a[:]=(.86,.66,.37) if calm else (.82,.61,.32);a+=broad[:,:,None];a-=line[:,:,None]*np.array((.115,.095,.065) if calm else (.20,.145,.075))
    cells=np.floor(xx*67)+np.floor(yy*35)*113
    fleck=((np.sin(cells*12.9898)*43758.5453)%1-.5)*.035
    a+=fleck[:,:,None];a+=((yy+1)/2)[:,:,None]*np.array((.025,.025,.01))
    for t,st in [(.3,.7),(2.5,.76),(4.9,.83)]:
        d=np.abs((theta-t+math.pi)%math.tau-math.pi)
        a-=((d<.006)&(rad>st))[:,:,None]*np.array((.20,.14,.08))
    cut=image_array('Golden endgrain source',a,folder/'endgrain_source.png',legacy=legacy)
    return bark,cut

def paint_material(name,im):
    m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;n.clear()
    out=n.new('ShaderNodeOutputMaterial');em=n.new('ShaderNodeEmission');tex=n.new('ShaderNodeTexImage');tex.image=im
    uv=n.new('ShaderNodeUVMap');uv.uv_map='PaintUV';l.new(uv.outputs[0],tex.inputs[0]);l.new(tex.outputs['Color'],em.inputs[0]);l.new(em.outputs[0],out.inputs[0]);return m

def mesh(name,verts,faces):
    d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update();o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True);return o

def assign_uv(o,mode='cylinder',trim=False):
    d=o.data;uv=d.uv_layers.new(name='PaintUV')
    for p in d.polygons:
        cut=p.normal.z>.70 and p.center.z>1.0
        p.material_index=1 if cut else 0
        if cut:
            for li in p.loop_indices:
                co=d.vertices[d.loops[li].vertex_index].co;uv.data[li].uv=(.5+co.x/1.55,.5+co.y/1.55)
        else:
            aa=[math.atan2(d.vertices[d.loops[li].vertex_index].co.y,d.vertices[d.loops[li].vertex_index].co.x)/math.tau+.5 for li in p.loop_indices]
            if max(aa)-min(aa)>.5:aa=[a+1 if a<.5 else a for a in aa]
            for li,a in zip(p.loop_indices,aa):
                co=d.vertices[d.loops[li].vertex_index].co
                uv.data[li].uv=(a,co.z/1.4)
    return uv

def active(o):
    bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o

def bake_color(o,folder):
    active(o);d=o.data
    bake=d.uv_layers.new(name='BakeUV');d.uv_layers.active=bake
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.1,island_margin=.018);bpy.ops.object.mode_set(mode='OBJECT')
    im=bpy.data.images.new('Stump paint atlas',width=1024,height=1024,alpha=False)
    for m in d.materials:
        n=m.node_tree.nodes;tex=n.new('ShaderNodeTexImage');tex.image=im;n.active=tex;tex.select=True
    bpy.context.scene.render.bake.margin=12;bpy.ops.object.bake(type='EMIT')
    im.filepath_raw=str(folder/'paint_atlas.png');im.file_format='PNG';im.save();im.pack()
    m=bpy.data.materials.new('Baked hand-painted wood');m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links
    bs=n.get('Principled BSDF');bs.inputs['Roughness'].default_value=.88
    tex=n.new('ShaderNodeTexImage');tex.image=im;l.new(tex.outputs['Color'],bs.inputs['Base Color'])
    # Gentle emission retains painted color under the fixed studio rig.
    bs.inputs['Emission Strength'].default_value=.12;l.new(tex.outputs['Color'],bs.inputs['Emission Color'])
    d.materials.clear();d.materials.append(m)
    for p in d.polygons:p.material_index=0
    for layer in list(d.uv_layers):
        if layer.name!='BakeUV':d.uv_layers.remove(layer)
    d.uv_layers.active_index=0;d.uv_layers[0].active_render=True
    return m

def render_export(o,folder,revision,meta):
    active(o)
    for p in o.data.polygons:p.use_smooth=not(p.normal.z>.70 and p.center.z>.90)
    o.name=folder.name+' | authored stump';o.data.name=o.name
    bpy.ops.wm.save_as_mainfile(filepath=str(folder/f'stump_{revision}.blend'))
    bpy.ops.export_scene.gltf(filepath=str(folder/f'stump_{revision}.glb'),export_format='GLB',use_selection=True,export_yup=True)
    coords=[v.co for v in o.data.vertices];bm=bmesh.new();bm.from_mesh(o.data)
    meta.update(vertices=len(o.data.vertices),faces=len(o.data.polygons),triangles=sum(len(p.vertices)-2 for p in o.data.polygons),nonmanifold_edges=sum(not e.is_manifold for e in bm.edges),dimensions=list(o.dimensions),materials=len(o.data.materials),uv_layers=[u.name for u in o.data.uv_layers]);bm.free()
    (folder/f'geometry_{revision}.json').write_text(json.dumps(meta,indent=2))
    cam=review_rig.setup(res=(800,720),scale=3.65,target=(0,0,.65));bpy.context.scene.cycles.samples=20
    for name,loc in [('front',(3.5,-6.4,3.5)),('back',(-3.5,6.4,3.5)),('side',(6.4,3.5,3.5))]:review_rig.shot(cam,folder/f'{name}_{revision}.png',loc=loc,target=(0,0,.65))
    print('STUMP_BUILD_OK',folder.name,revision,json.dumps(meta))

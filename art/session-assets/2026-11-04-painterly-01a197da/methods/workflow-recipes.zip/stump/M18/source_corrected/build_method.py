"""Replay: blender -b --python build_method.py -- M15 initial|corrected."""
import bpy,bmesh,math,sys,json,random
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
from lab_common import *
args=sys.argv[sys.argv.index('--')+1:];method=args[0];rev=args[1] if len(args)>1 else 'initial';corrected=rev!='initial'
folder=ROOT/method;folder.mkdir(exist_ok=True);clear()

def radial_body(name,n=96,layers=18,seed=3,height=1.34,roots=None):
    rng=random.Random(seed)
    if roots is None:roots=[(-.25,.72,.17),(.88,.48,.22),(2.25,.66,.20),(3.35,.40,.24),(4.6,.77,.18),(5.55,.31,.16)]
    verts=[];faces=[]
    for k in range(layers):
        t=k/(layers-1);z=height*t
        # Flowing flare tapers out progressively along each root strip.
        for j in range(n):
            a=math.tau*j/n
            root_profile=(1-t)**3.2*((.90+5*t) if corrected else 1)
            flare=sum(length*math.exp(-.5*(((a-ang+math.pi)%math.tau-math.pi)/(width+.12*t))**2) for ang,length,width in roots)*root_profile
            r=.61+.11*(1-t)**2+flare+.018*math.sin(a*9+.6)+.013*math.sin(a*17+t*.8)
            zz=z+(.015*math.sin(a*5)+.009*math.sin(a*13))*t
            verts.append((r*math.cos(a)+.065*t*t,r*math.sin(a)-.04*t*t,zz))
    for k in range(layers-1):
        for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
    # Concentric cap with a small raised bark rim, continuous radial strips.
    prev=(layers-1)*n
    for q in range(1,8):
        frac=1-q/8;start=len(verts)
        for j in range(n):
            a=math.tau*j/n;co=Vector(verts[(layers-1)*n+j]);verts.append((co.x*frac+.065*(1-frac),co.y*frac-.04*(1-frac),height-.022+.006*math.sin(a*5)*frac))
        for j in range(n):faces.append((prev+j,prev+(j+1)%n,start+(j+1)%n,start+j))
        prev=start
    center=len(verts);verts.append((.065,-.04,height-.024))
    for j in range(n):faces.append((prev+j,prev+(j+1)%n,center))
    faces.append(tuple(reversed(range(n))))
    return mesh(name,verts,faces)

def swept_root(points,radii,name):
    n=16;verts=[];faces=[]
    for k,(point,rad) in enumerate(zip(points,radii)):
        p=Vector(point);t=(Vector(points[min(k+1,len(points)-1)])-Vector(points[max(k-1,0)])).normalized();side=t.cross(Vector((0,0,1))).normalized();up=side.cross(t).normalized()
        for j in range(n):
            a=math.tau*j/n;v=p+side*math.cos(a)*rad+up*math.sin(a)*rad*.75;v.z=max(v.z,.025);verts.append(v)
    for k in range(len(points)-1):
        for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
    faces.append(tuple(reversed(range(n))));faces.append(tuple((len(points)-1)*n+j for j in range(n)))
    return mesh(name,verts,faces)

if method=='M15':
    # Distinct workflow: overlapping swept volumes are unified as an implicit voxel field.
    bpy.ops.mesh.primitive_cone_add(vertices=64,radius1=.76,radius2=.63,depth=1.62,location=(0,0,.78));body=bpy.context.object
    if corrected:bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
    pieces=[body]
    specs=[(-.4,1.45,.28),(.95,1.06,.24),(2.25,1.35,.32),(3.45,1.08,.21),(4.8,1.50,.30),(5.6,1.15,.22)]
    if corrected:specs=[(-.4,1.48,.30),(.95,1.00,.18),(2.25,1.36,.32),(3.45,.91,.16),(4.8,1.58,.31)]
    for i,(a,length,width) in enumerate(specs):
        points=[];radii=[]
        for k in range(8):
            t=k/7;r=.35+(length-.35)*t;aa=a+.12*math.sin(t*math.pi)
            points.append((r*math.cos(aa),r*math.sin(aa),.66*(1-t)**2+.05));radii.append(width*(1-t)**.7+.045)
        pieces.append(swept_root(points,radii,'Root implicit input'))
    active(body)
    for p in pieces:p.select_set(True)
    bpy.ops.object.join();rem=body.modifiers.new('Implicit union .035m','REMESH');rem.mode='VOXEL';rem.voxel_size=.035 if corrected else .055;rem.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=rem.name)
    sm=body.modifiers.new('Union relaxation','SMOOTH');sm.factor=1.1;sm.iterations=4;bpy.ops.object.modifier_apply(modifier=sm.name)
    # Real plane cut after union; no round over on the cut surface.
    bm=bmesh.new();bm.from_mesh(body.data);geom=list(bm.verts)+list(bm.edges)+list(bm.faces)
    ret=bmesh.ops.bisect_plane(bm,geom=geom,dist=.0001,plane_co=(0,0,1.32),plane_no=(0,0,1),clear_outer=True)
    boundary=[e for e in bm.edges if e.is_boundary];bmesh.ops.holes_fill(bm,edges=boundary,sides=0);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(body.data);bm.free();body.data.update()
    o=body
elif method=='M16':
    roots=[(-.12,.79,.17),(1.10,.48,.20),(2.30,.60,.19),(3.45,.45,.20),(4.65,.71,.17),(5.50,.47,.18)]
    if corrected:roots=[(-.12,.88,.18),(1.1,.33,.16),(2.35,.65,.23),(3.50,.30,.15),(4.68,.83,.21),(5.50,.25,.16)]
    o=radial_body('Continuous radial strips | no union',n=96,layers=20,roots=roots,height=1.05 if rev=='refined' else (1.30 if corrected else 1.40))
elif method=='M17':
    roots=[(.12,.72,.20),(1.65,.38,.18),(2.65,.70,.23),(3.65,.31,.17),(4.80,.83,.21),(5.55,.36,.16)]
    if not corrected:roots=[(a,l*.66,w) for a,l,w in roots]
    o=radial_body('Bake target low topology',n=64,layers=14,seed=17,height=1.05 if corrected else 1.24,roots=roots)
elif method=='M18':
    roots=[(.25,.72,.21),(1.43,.32,.19),(2.60,.59,.23),(3.55,.44,.17),(4.55,.74,.21),(5.6,.29,.17)]
    o=radial_body('Meridian curve loft for trim UV',n=96,layers=26,seed=18,height=1.06 if corrected else 1.44,roots=roots)
elif method=='M19':
    roots=[(-.33,.68,.21),(.76,.35,.16),(1.9,.55,.22),(3.14,.72,.24),(4.15,.27,.17),(5.10,.80,.22)]
    o=radial_body('Projection target authored from elevation proportions',n=128,layers=26,height=1.05 if corrected else 1.40,roots=roots)
elif method=='M20':
    roots=[(.1,.77,.22),(1.4,.42,.21),(2.57,.71,.23),(3.65,.30,.18),(4.72,.82,.22),(5.65,.35,.16)]
    o=radial_body('Boolean cavity designed solid',n=96,layers=22,height=1.24,roots=roots)
    # Actual subtractive modelling, not a painted dark disk.
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,location=(.14,-.06,1.32));c=bpy.context.object;c.name='Cavity cutter source';c.scale=(.44,.42,.68 if not corrected else .58)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    active(o);mod=o.modifiers.new('Rotten heart subtraction','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=c;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(c,do_unlink=True)
    if not corrected:
        # First trial has an overly regular missing wedge.
        bpy.ops.mesh.primitive_cube_add(size=1,location=(.34,-.47,1.24));c=bpy.context.object;c.scale=(.38,.55,.60);c.rotation_euler.z=-.28
    else:
        # Revised organic bite: small irregular lobe, retaining most of the golden rim.
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1,location=(.37,-.43,1.30));c=bpy.context.object;c.scale=(.25,.26,.39)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    active(o);mod=o.modifiers.new('Broken rim subtraction','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=c;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(c,do_unlink=True)
    bevel=o.modifiers.new('Selective broken edge softness','BEVEL');bevel.width=.009;bevel.segments=1;bevel.limit_method='ANGLE';bpy.ops.object.modifier_apply(modifier=bevel.name)
else:raise ValueError(method)

texfolder=folder/('textures_'+rev);texfolder.mkdir(exist_ok=True)
if (corrected and method in ['M17','M18','M19','M20']) or rev=='refined':
    import shutil
    palette=ROOT.parents[1]/'palette'
    if not palette.exists():palette=ROOT.parents[1]/'stump_painterly_v1'/'Textures'
    for imname in ['bark_painted.png','endgrain_painted.png']:shutil.copy2(palette/imname,texfolder/imname)
    bark=bpy.data.images.load(str(texfolder/'bark_painted.png'));cut=bpy.data.images.load(str(texfolder/'endgrain_painted.png'));bark.pack();cut.pack()
    (folder/('pigment_source_'+rev+'.json')).write_text(json.dumps({'source':'earlier stump PNG pigments only; geometry newly authored','bark':'textures_'+rev+'/bark_painted.png','endgrain':'textures_'+rev+'/endgrain_painted.png'},indent=2))
else:bark,cut=make_paints(texfolder,seed=int(method[1:])+4,calm=corrected,trim=method=='M18',legacy=method=='M15' and not corrected)
o.data.materials.append(paint_material('Bark paint process',bark));o.data.materials.append(paint_material('Cut face paint process',cut));assign_uv(o)
if corrected and method!='M15':
    # Recover upward cut normals for deliberately shorter stumps.
    uv=o.data.uv_layers['PaintUV']
    for p in o.data.polygons:
        if p.normal.z>.70 and p.center.z>.90:
            p.material_index=1
            for li in p.loop_indices:
                co=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=(.5+(co.x-.065)/1.40,.5+(co.y+.04)/1.40)
        elif method!='M18':
            for li in p.loop_indices:
                uv.data[li].uv.x*=1.80
                uv.data[li].uv.y*=1.4/(1.24 if method=='M20' else 1.05)

if method=='M18':
    # Curves of cumulative meridian length straighten grain across the curved root shoulder.
    n=96;layers=26;distance={}
    for j in range(n):
        dd=[0.0]
        for k in range(1,layers):dd.append(dd[-1]+(o.data.vertices[k*n+j].co-o.data.vertices[(k-1)*n+j].co).length)
        for k in range(layers):distance[k*n+j]=dd[k]/dd[-1]
    uv=o.data.uv_layers['PaintUV']
    for p in o.data.polygons:
        if p.material_index:continue
        js=[o.data.loops[li].vertex_index%n for li in p.loop_indices]
        panel=(min(js)//24)%4
        for li in p.loop_indices:
            vi=o.data.loops[li].vertex_index;j=vi%n
            local=((j%24)/24)
            if (j%24==0) and j!=min(js):local=1
            # Initial uniform-height UV is retained as failure comparison; corrected uses arc length.
            v=distance.get(vi,1) if corrected else o.data.vertices[vi].co.z/1.44
            uv.data[li].uv=(panel*.25+.018+local*.214,v)
    (folder/f'trim_uv_{rev}.json').write_text(json.dumps({'panel_count':4,'mapping':'per-meridian cumulative geometric arc length' if corrected else 'uniform vertical height; roots compress grain','curves':96,'samples_per_curve':26},indent=2))

if method=='M19':
    from projection_paint import apply_projection
    apply_projection(o,folder,corrected)
if method=='M20':
    from projection_paint import cavity_paint
    cavity_paint(o,folder,corrected)

high=None
if method=='M17':
    # A real independent high poly sculpt is retained as a separate source file.
    high=o.copy();high.data=o.data.copy();bpy.context.collection.objects.link(high);high.name='HIGH | engraved bark and cut rings'
    active(high);sub=high.modifiers.new('Dense sculpt lattice','SUBSURF');sub.subdivision_type='SIMPLE';sub.levels=3;bpy.ops.object.modifier_apply(modifier=sub.name)
    for v in high.data.vertices:
        x,y,z=v.co;rr=math.hypot(x-.065,y+.04);a=math.atan2(y+.04,x-.065)
        if z>(1.005 if corrected else 1.195) and rr<.60:
            phase=rr*math.tau*8+.15*math.sin(a*5);inc=-.008*math.exp(-(math.sin(phase)/.22)**2)
            v.co.z+=inc
        else:
            phase=a*15+.19*math.sin(z*7+a*2);groove=math.exp(-(math.sin(phase)/.19)**2)
            inc=-(.024 if not corrected else .012)*groove+.004*math.sin(a*37+z*9)
            v.co.x+=math.cos(a)*inc;v.co.y+=math.sin(a)*inc
    high.data.update();active(high);o.hide_set(True);bpy.ops.wm.save_as_mainfile(filepath=str(folder/f'high_sculpt_{rev}.blend'));o.hide_set(False);high.hide_set(True)

mat=bake_color(o,texfolder)
if method=='M17':
    # Tangent normal selected-to-active bake from the engraved high mesh.
    im=bpy.data.images.new('Engraving tangent normal',width=1024,height=1024,alpha=False);im.colorspace_settings.name='Non-Color'
    tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=im;mat.node_tree.nodes.active=tex
    high.hide_set(False);active(o);high.select_set(True);bpy.context.view_layer.objects.active=o
    scene=bpy.context.scene;scene.render.bake.use_selected_to_active=True;scene.render.bake.cage_extrusion=.07;scene.render.bake.max_ray_distance=.14;scene.render.bake.margin=12
    bpy.ops.object.bake(type='NORMAL');scene.render.bake.use_selected_to_active=False
    im.filepath_raw=str(folder/'engraved_normal.png');im.file_format='PNG';im.save();im.pack()
    nn=mat.node_tree.nodes.new('ShaderNodeNormalMap');nn.inputs['Strength'].default_value=1 if not corrected else .66;mat.node_tree.links.new(tex.outputs['Color'],nn.inputs['Color']);mat.node_tree.links.new(nn.outputs[0],mat.node_tree.nodes.get('Principled BSDF').inputs['Normal'])
    (folder/f'bake_evidence_{rev}.json').write_text(json.dumps({'low_vertices':len(o.data.vertices),'high_vertices':len(high.data.vertices),'bake':'NORMAL selected_to_active tangent','cage_extrusion':.07,'max_ray_distance':.14,'sculpt':'actual displaced geometry: 15 flowing bark fissures and 8 endgrain rings'},indent=2))
    bpy.data.objects.remove(high,do_unlink=True)
workflows={'M15':'swept solid roots + tapered trunk -> voxel implicit union -> relax -> planar cut -> UV paint bake','M16':'continuous meridional strips and concentric cut face -> cylindrical brush projection -> atlas bake','M17':'low target authored -> dense independent engraved high surface -> actual selected-to-active tangent normal bake + painted color atlas','M18':'curve loft -> four directional bark trim panels -> cumulative meridian distance UV reuse -> atlas','M19':'four painted elevation concept plates -> actual per-loop normal-weighted multi-view projection -> correction strokes -> paint atlas bake','M20':'solid stump -> exact Boolean heart cavity and broken rim subtraction -> selective cavity/edge/growth paint -> atlas bake'}
render_export(o,folder,rev,{'method':method,'revision':rev,'workflow':workflows[method]})

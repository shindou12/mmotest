"""Actual painted view-plate projection and geometry-aware selective paint."""
import bpy,numpy as np,math,json
from lab_common import image_array,srgb

def vertex_material(o,name,colors,masks=None):
    attr=o.data.color_attributes.new(name='ProjectionPaint',type='FLOAT_COLOR',domain='CORNER')
    for li,c in enumerate(colors):attr.data[li].color=tuple(srgb(np.clip(c,0,1)))+((float(masks[li]) if masks is not None else 1),)
    m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;n.clear();a=n.new('ShaderNodeVertexColor');a.layer_name='ProjectionPaint';e=n.new('ShaderNodeEmission');out=n.new('ShaderNodeOutputMaterial')
    if masks is not None:
        old=o.data.materials[0];image=next(x.image for x in old.node_tree.nodes if x.type=='TEX_IMAGE')
        tex=n.new('ShaderNodeTexImage');tex.image=image;uv=n.new('ShaderNodeUVMap');uv.uv_map='PaintUV';l.new(uv.outputs[0],tex.inputs[0]);mix=n.new('ShaderNodeMixRGB');l.new(a.outputs['Alpha'],mix.inputs[0]);l.new(tex.outputs['Color'],mix.inputs[1]);l.new(a.outputs['Color'],mix.inputs[2]);l.new(mix.outputs[0],e.inputs[0])
    else:l.new(a.outputs['Color'],e.inputs[0])
    l.new(e.outputs[0],out.inputs[0])
    o.data.materials[0]=m

def apply_projection(o,folder,corrected):
    n=1024;yy,xx=np.mgrid[0:n,0:n].astype(float);s=xx/n;t=yy/n;plates=[]
    for index,view in enumerate(['front','back','left','right']):
        flow=s+.019*np.sin(t*7+index)+.007*np.sin(t*19+s*7)
        band=np.sin(flow*math.tau*7+index*.8)
        cell=np.floor(flow*27)+np.floor((t+.02*np.sin(flow*45))*21)*47
        brush=np.floor(((np.sin(cell*17.13+index)*4413.62)%1)*4)/4-.35
        a=np.zeros((n,n,3));a[:]=(.48,.30,.16)
        a+=(band*.07+brush*.13)[:,:,None]*np.array((1,.87,.64))
        # Broad intentionally different light/shadow strokes on each concept elevation.
        highlight=np.exp(-((s-(.32+.07*math.sin(index))) /.115)**2)*(t>.22)*(.4+.6*t)
        a+=highlight[:,:,None]*np.array((.13,.105,.055))
        fiss=np.exp(-(np.sin(flow*math.tau*8+index*.7)/.075)**2)
        a-=fiss[:,:,None]*np.array((.13,.09,.045))
        moss=((np.sin(s*21+index)+np.sin(t*15-s*43))>1.35)*(t<.19)
        a[moss]=(.32,.37,.14)
        # A diagrammatic outer silhouette is saved in alpha-free plate margins.
        silhouette_width=.21+.25*(1-t)**3+.025*np.sin(t*8+index)
        outside=np.abs(s-.5)>silhouette_width
        a[outside]=(.19,.23,.23)
        if corrected:
            # Repainted concept plates use the successful earlier hand-painted pigment source,
            # reframed independently per elevation. Only images are reused, never geometry.
            im=bpy.data.images.load(str(folder/'textures_corrected'/'bark_painted.png'));pix=np.asarray(im.pixels[:]).reshape(im.size[1],im.size[0],4)[:,:,:3]
            # image pixels are linear on loaded PNG; convert for authored view plate storage.
            pix=np.where(pix<=.0031308,pix*12.92,1.055*np.maximum(pix,0)**(1/2.4)-.055)
            ix=((s*1.45+index*.227)%1*(im.size[0]-1)).astype(int);iy=(np.clip(t,0,.999)*(im.size[1]-1)).astype(int)
            a=pix[iy,ix]*np.array((.88,.89,.91));a+=highlight[:,:,None]*np.array((.025,.018,.009))
            a[outside]=(.19,.23,.23)
        image_array('Concept elevation '+view,a,folder/f'concept_{view}_{"corrected" if corrected else "initial"}.png');plates.append(a)
    cols=[];d=o.data
    for p in d.polygons:
        for li in p.loop_indices:
            co=d.vertices[d.loops[li].vertex_index].co;normal=p.normal
            # Orthographic view projection samples the actual image pixels, not a stand-in shader.
            uv=[(co.x/3+.5,co.z/1.5),(1-(co.x/3+.5),co.z/1.5),(co.y/3+.5,co.z/1.5),(1-(co.y/3+.5),co.z/1.5)]
            weights=np.array([max(-normal.y,0),max(normal.y,0),max(-normal.x,0),max(normal.x,0)])**(4 if not corrected else 2)
            if weights.sum()<.01:weights=np.ones(4)
            weights/=weights.sum();c=np.zeros(3)
            for k,(u,v) in enumerate(uv):
                if corrected:u=np.clip(u,.31,.69) # suppress background bleeding on the wide root shoulders
                c+=plates[k][int(np.clip(v,0,.999)*n),int(np.clip(u,0,.999)*n)]*weights[k]
            if corrected:
                # Painted unifying glaze reduces cross-view seams and restores warm upper planes.
                c=c*.78+np.array((.49,.32,.17))*.22
                c+=np.array((.045,.032,.01))*max(0,normal.z)*min(co.z,1)
            cols.append(c)
    vertex_material(o,'Multi-view painted concept projection',cols)
    (folder/('projection_corrected.json' if corrected else 'projection_initial.json')).write_text(json.dumps({'actual_sources':['concept_front.png','concept_back.png','concept_left.png','concept_right.png'],'projection':'orthographic x/z and y/z lookup on each mesh corner','blend':'positive-facing normal weights squared' if corrected else 'positive-facing normal weights power four','correction':'background exclusion + warm unifying glaze' if corrected else None},indent=2))

def cavity_paint(o,folder,corrected):
    d=o.data;cols=[];masks=[];edge_points=[]
    for edge in d.edges:
        v1=d.vertices[edge.vertices[0]].co;v2=d.vertices[edge.vertices[1]].co
        if v1.z>1.03 and v2.z>1.03:edge_points.append((v1+v2)*.5)
    for p in d.polygons:
        # Cut and cavity use different rules; the cavity is genuine geometry.
        c=p.center;inner=math.hypot(c.x-.14,c.y+.06)<.47 and c.z>.64
        if inner:p.material_index=0
        for li in p.loop_indices:
            co=d.vertices[d.loops[li].vertex_index].co;a=math.atan2(co.y,co.x);z=co.z
            flow=a+.10*math.sin(z*5);rid=math.sin(flow*16)
            cell=math.floor(a*15)+math.floor(z*24)*47
            stroke=((math.sin(cell*12.989)*4437.5)%1-.5)*.10
            base=np.array((.47,.30,.15))+(rid*.055+stroke)*np.array((1,.85,.6))
            r=math.hypot(co.x-.14,co.y+.06)
            if inner:base=np.array((.235,.135,.065))+max(0,z-.7)*np.array((.11,.08,.04))
            # Select only broken high edges for pale exposed fibres. No uniform outline.
            broken=max(0,1-abs(r-.43)/.07)*max(0,min((z-.96)/.18,1))
            if corrected and co.y<.10:base=base*(1-broken*.50)+np.array((.78,.56,.28))*broken*.50
            growth=max(0,math.sin(a*3-.8))*max(0,math.sin(z*13+a*4))*max(0,1-z/.31)
            if corrected and a>1.0:base=base*(1-growth*.5)+np.array((.33,.38,.14))*growth*.5
            cols.append(base);masks.append(1 if inner else (min(.55,broken*.50+growth*.35) if corrected else .0))
    vertex_material(o,'Selective exposed fibres and growth paint',cols,masks)
    (folder/f'cavity_paint_{"corrected" if corrected else "initial"}.json').write_text(json.dumps({'geometry':'exact boolean hollow and separate missing rim volume','paint':'dark interior; selective broken high-edge warm fibres and low rear olive growth' if corrected else 'dark interior with no edge recovery','edge_point_count':len(edge_points)},indent=2))

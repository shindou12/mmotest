Painterly_Cargo_Cart_Asset
BLEND: editable model only. GLB: optimized runtime model with embedded images.
Textures are extracted from the exact GLB; no camera, light, staging floor, or scene is included.
The source recipe and research records are supplied separately.

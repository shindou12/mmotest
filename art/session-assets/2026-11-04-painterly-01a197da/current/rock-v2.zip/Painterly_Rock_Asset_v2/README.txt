Painterly Rock v2 - rebuilt from blockout

Rock_Painterly_v2.glb: ready to import, texture embedded.
Rock_Painterly_v2.blend: editable asset mesh with packed colour texture.
Textures/rock_v2_basecolor.png: 2048 x 2048 sRGB colour atlas.

262 triangles, 1 connected closed mesh, 1 material, 1 UV set.
Metres. Blender Z-up; GLB Y-up. Origin at ground centre.
Dimensions ~2.59 x 2.09 x 1.52 m in Blender XYZ.
Roughness 0.92, metallic 0. No extra maps required.
Six blockouts were reviewed; design E was selected and repainted after a flat-looking first colour pass.
Authored Blender geometry, face palette, directional pigment and local moss; UV atlas repainted with image_gen and rebaked.
No scene, presentation ground, camera, light or viewer is included.
GLB re-import, manifold topology, one connected component, embedded texture match and ZIP CRC verified.
The previous version remains saved separately.

Painterly Stump

Model-only asset: 9,216 triangles, one mesh, one material. Meters, origin on floor.
GLB is self-contained. BLEND references the same three images in the included Textures folder.
No camera, light, display floor or generated reference plane is included.

Textures (2048 x 2048):
basecolor.png: sRGB, painted color (no baked AO or cast floor shadow).
normal.png: Non-Color / linear, tangent-space OpenGL normal, strength 0.32.
orm.png: Non-Color / linear, R=self-AO (strength 0.22), G=roughness, B=metallic (0).
Do not multiply AO into color a second time.

The image-generated painting contains authored tonal strokes. Fine relief is
baked from a high-density mesh; the main ridges and rim chips are real geometry.


配布用BLENDは同梱のTexturesを相対パスで参照します。ZIPをフォルダごと展開して使用してください。画像内容・GLB・形状・UV・法線は変更していません。

Original stump, untextured view.
Exact geometry and smoothing from the first painted stump.
Only the material was replaced by neutral clay. No texture or normal maps.
One model only: no camera, light or staging floor.

Crate Sol — Painted X variant

Variant of Crate Sol 01. The original 3D X asset is preserved separately.
The four side panels are flat boxes. All X reinforcement, vertical plank seams,
brush grain, edge highlights and contact shadows are painted into base color.
No diagonal geometry, normal map or shader is required at runtime.

444 triangles / 264 source vertices (original: 684 / 424).
Reduction: 240 triangles (35.1%) and 160 source vertices (37.7%).
Dimensions: 0.802 x 0.802 x 0.799 m. Origin at ground center. Bottom Z=0.
1 mesh / 1 material / embedded 1024x1024 sRGB base-color atlas.
GLTF seams may split source vertices into multiple exported vertices.

Files:
crate_sol_painted_x.glb — glTF Y-up asset with embedded texture
crate_sol_painted_x.blend — editable Blender Z-up asset, no preview scene
crate_painted_x_basecolor.png — base-color texture

QC: GLB reimported into Blender. Diagonal three-quarter views, 192px and 96px
comparisons checked. Painted highlights/shadows preserve the X at distance;
grazing angles naturally have no parallax or raised silhouette on the X.
The outer frame remains modeled for silhouette and real corner shadows.
No B01/mmotest scene changes, collisions or scripts included.

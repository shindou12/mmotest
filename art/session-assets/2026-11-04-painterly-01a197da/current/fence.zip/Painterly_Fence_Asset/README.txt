Painterly Fence - standalone game asset, revision 2

Fence_Painterly.glb: ready to import, texture embedded.
Fence_Painterly.blend: editable mesh referencing the included Textures folder, asset only.
Textures/fence_basecolor.png: 2048 x 2048 sRGB colour atlas.

1 mesh, 1 material, 1 UV set, 1,808 triangles. Closed component surfaces.
2 posts, 2 rails, 1 diagonal brace, 8 bolt heads with washers.
Metres. Blender Z-up; GLB Y-up. Origin: ground centre.
Dimensions ~2.43 x 0.41 x 1.65 m in Blender XYZ. Post base centres: 2.10 m apart.
Roughness 0.92, metallic 0. No additional maps required.
Painterly sawn-wood and endgrain textures, moss and artistic height shading are baked into base colour.
Generated surface artwork and authored Blender geometry. No add-on is required.
No stage, ground, camera, light or viewer is included.
GLB re-import, welded-UV topology and embedded texture byte match verified.


配布用BLENDは同梱のTexturesを相対パスで参照します。ZIPをフォルダごと展開して使用してください。画像内容・GLB・形状・UV・法線は変更していません。

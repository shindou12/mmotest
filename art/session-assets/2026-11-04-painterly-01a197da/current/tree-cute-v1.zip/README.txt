Cute Broadleaf A

Model-only Blender and self-contained GLB asset. Origin at ground, meters.
One mesh, one material, one packed 2048x2048 sRGB color image.
Roughness 0.95, metallic 0; no AO/normal/roughness textures.
Closed continuous wood, five closed support masses and curved leaf groups.
Non-overlapping baked UV atlas; source painting is reused across leaf groups.
Color contains painted strokes and authored top/underside tones; no scene light,
ground shadow or baked object AO. No camera, light or display ground included.
